package com.makeito.servlet;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class QuoteServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int projectId = Integer.parseInt(request.getParameter("projectId"));
        double amount = Double.parseDouble(request.getParameter("amount"));
        String message = request.getParameter("message");

        HttpSession session = request.getSession();
        String vendorEmail = (String) session.getAttribute("userEmail");

        Connection con = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/makeito_db",
                "root",
                "root"
            );

            // 🔎 Check project status
            PreparedStatement check = con.prepareStatement(
                "SELECT status FROM projects WHERE id=?"
            );
            check.setInt(1, projectId);

            ResultSet rsCheck = check.executeQuery();

            if(!rsCheck.next()) {
                con.close();
                response.sendRedirect("vendor.jsp");
                return;
            }

            if(!"OPEN".equals(rsCheck.getString("status"))) {
                con.close();
                response.sendRedirect("vendor.jsp");
                return;
            }

            // ✅ Insert quote
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO quotes(project_id,vendor_email,amount,message,status) VALUES(?,?,?,?,?)"
            );

            ps.setInt(1, projectId);
            ps.setString(2, vendorEmail);
            ps.setDouble(3, amount);
            ps.setString(4, message);
            ps.setString(5, "PENDING");

            ps.executeUpdate();

            con.close();

            response.sendRedirect("vendor.jsp");

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}
