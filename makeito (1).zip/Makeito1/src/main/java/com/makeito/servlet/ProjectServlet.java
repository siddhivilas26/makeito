package com.makeito.servlet;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class ProjectServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String title = request.getParameter("title");
        String description = request.getParameter("description");
        double budget = Double.parseDouble(request.getParameter("budget"));

        HttpSession session = request.getSession();
        String customerEmail = (String) session.getAttribute("userEmail");

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/makeito_db",
                "root",
                "root"
            );

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO projects(title,description,budget,customer_email) VALUES(?,?,?,?)"
            );

            ps.setString(1, title);
            ps.setString(2, description);
            ps.setDouble(3, budget);
            ps.setString(4, customerEmail);

            ps.executeUpdate();

            con.close();

            response.sendRedirect("customer.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
