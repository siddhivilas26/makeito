package com.makeito.servlet;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class UpdateOrderStatusServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int orderId = Integer.parseInt(request.getParameter("orderId"));
        String newStatus = request.getParameter("status");

        HttpSession session = request.getSession();
        String vendorEmail = (String) session.getAttribute("userEmail");
        String role = (String) session.getAttribute("userRole");

        if(role == null || !role.equals("VENDOR")){
            response.sendRedirect("login.jsp");
            return;
        }

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/makeito_db",
                "root",
                "root"
            );

            // Security check: ensure vendor owns this order
            PreparedStatement check = con.prepareStatement(
                "SELECT vendor_email FROM orders WHERE id=?"
            );
            check.setInt(1, orderId);

            ResultSet rs = check.executeQuery();

            if(rs.next()) {

                if(!vendorEmail.equals(rs.getString("vendor_email"))) {
                    con.close();
                    response.sendRedirect("vendorOrders.jsp");
                    return;
                }

                PreparedStatement update = con.prepareStatement(
                    "UPDATE orders SET status=? WHERE id=?"
                );
                update.setString(1, newStatus);
                update.setInt(2, orderId);
                update.executeUpdate();
            }

            con.close();

            response.sendRedirect("vendorOrders.jsp");

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}
