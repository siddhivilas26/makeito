package com.makeito.servlet;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class AcceptQuoteServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int quoteId = Integer.parseInt(request.getParameter("quoteId"));
        int projectId = Integer.parseInt(request.getParameter("projectId"));
        float totalamount = Float.parseFloat(request.getParameter("amount"));
        float advanceAmount = Float.parseFloat(request.getParameter("advanceAmount"));
       int order_id =0;
        float remaining_amount = totalamount - advanceAmount;

        Connection con = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/makeito_db",
                "root",
                "root"
            );

            // 🔎 Get selected quote details
            PreparedStatement getQuote = con.prepareStatement(
                "SELECT * FROM quotes WHERE id=?"
            );
            getQuote.setInt(1, quoteId);

            ResultSet rs = getQuote.executeQuery();

            if(!rs.next()){
                response.sendRedirect("viewQuotes.jsp");
                return;
            }

            String vendorEmail = rs.getString("vendor_email");
            double amount = rs.getDouble("amount");

            // 1️⃣ Accept selected quote
            PreparedStatement ps1 = con.prepareStatement(
                "UPDATE quotes SET status='ACCEPTED' WHERE id=?"
            );
            ps1.setInt(1, quoteId);
            ps1.executeUpdate();

            // 2️⃣ Reject other quotes
            PreparedStatement ps2 = con.prepareStatement(
                "UPDATE quotes SET status='REJECTED' WHERE project_id=? AND id<>?"
            );
            ps2.setInt(1, projectId);
            ps2.setInt(2, quoteId);
            ps2.executeUpdate();

            // 3️⃣ Close project
            PreparedStatement ps3 = con.prepareStatement(
                "UPDATE projects SET status='CLOSED' WHERE id=?"
            );
            ps3.setInt(1, projectId);
            ps3.executeUpdate();

            // 4️⃣ Insert into orders table
            HttpSession session = request.getSession();
            String customerEmail = (String) session.getAttribute("userEmail");

            PreparedStatement ps4 = con.prepareStatement(
                "INSERT INTO orders(project_id,quote_id,customer_email,vendor_email,amount,status) VALUES(?,?,?,?,?,?)"
            );

            ps4.setInt(1, projectId);
            ps4.setInt(2, quoteId);
            ps4.setString(3, customerEmail);
            ps4.setString(4, vendorEmail);
            ps4.setDouble(5, amount);
            ps4.setString(6, "IN_PROGRESS");

            ps4.executeUpdate();
            

            PreparedStatement ps5 = con.prepareStatement(
                "select id from orders where project_id=?"
            );

            ps5.setInt(1, projectId);
            ResultSet rs1=ps5.executeQuery();
            while(rs1.next()) {order_id=rs1.getInt("id");}
            
            PreparedStatement ps6 = con.prepareStatement(
                    "INSERT INTO payments(order_id,total_amount,advance_amount,remaining_amount) VALUES(?,?,?,?)"
                );

                ps6.setInt(1, order_id);
                ps6.setFloat(2, totalamount);
                ps6.setFloat(3, advanceAmount);
                ps6.setFloat(4, remaining_amount);
               

                ps6.executeUpdate();
                

            

            con.close();

            response.sendRedirect("viewQuotes.jsp");

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}
