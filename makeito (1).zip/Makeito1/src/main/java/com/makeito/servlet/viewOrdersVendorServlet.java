package com.makeito.servlet;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class viewOrdersVendorServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        int project_id = 0;

        HttpSession session = request.getSession();
        String role = (String) session.getAttribute("userRole");

        if (role == null || !role.equals("VENDOR")) {
            response.sendRedirect("login.jsp");
            return;
        }

        // List to store project data
        List<List<Object>> orderList = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/makeito_db", "root", "root"
            );

            // ---------- FIRST QUERY ----------
            PreparedStatement ps = con.prepareStatement(
                "SELECT project_id FROM orders WHERE id=?"
            );
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                project_id = rs.getInt("project_id");
            }

            // ---------- SECOND QUERY ----------
            PreparedStatement ps1 = con.prepareStatement(
            	    "SELECT o.*, p.image_id FROM projects o " +
            	    "LEFT JOIN images_customer p ON o.id = p.id " +
            	    "WHERE o.id=?"
            	);
            	ps1.setInt(1, project_id);

            	ResultSet rs1 = ps1.executeQuery();

            	while (rs1.next()) {
            	    List<Object> proj = new ArrayList<>();

            	    proj.add(rs1.getInt("id"));                     // 0
            	    proj.add(rs1.getString("title"));               // 1
            	    proj.add(rs1.getString("description"));         // 2
            	    proj.add(rs1.getString("customer_email"));      // 3
            	    proj.add(rs1.getString("created_at"));          // 4

            	    int imgId = rs1.getInt("image_id");
            	    if (rs1.wasNull()) imgId = 0;
            	    proj.add(imgId);                                // 5

            	    orderList.add(proj);
            	}

            con.close();

            // SEND TO JSP
            request.setAttribute("orders", orderList);

            RequestDispatcher rd = request.getRequestDispatcher("viewOrdersVendor.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}