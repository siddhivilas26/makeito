package com.makeito.servlet;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@MultipartConfig(maxFileSize = 16177215)  // 16MB
public class ImageProjectUploadServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String title = request.getParameter("title");
        String description = request.getParameter("description");
        double budget = Double.parseDouble(request.getParameter("budget"));

        HttpSession session = request.getSession();
        String customerEmail = (String) session.getAttribute("userEmail");

        // Read uploaded file
        Part filePart = request.getPart("image");
        InputStream inputStream = null;

        if (filePart != null) {
            inputStream = filePart.getInputStream();
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/makeito_db",
                "root",
                "root"
            );

            // 1️⃣ Insert project
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO projects(title,description,budget,customer_email) VALUES(?,?,?,?)"
            );

            ps.setString(1, title);
            ps.setString(2, description);
            ps.setDouble(3, budget);
            ps.setString(4, customerEmail);

            ps.executeUpdate();

            // 2️⃣ Get inserted project ID
            PreparedStatement ps1 = con.prepareStatement(
                "SELECT id FROM projects WHERE title=? ORDER BY id DESC LIMIT 1"
            );

            ps1.setString(1, title);

            ResultSet rs = ps1.executeQuery();

            int project_id = 0;
            if (rs.next()) {
                project_id = rs.getInt("id");
            }

            // ⭐⭐⭐ ADDING IMAGE UPLOAD CODE HERE ⭐⭐⭐
            if (inputStream != null) {
                PreparedStatement ps2 = con.prepareStatement(
                    "INSERT INTO images_customer(id, image) VALUES (?, ?)"
                );

                ps2.setInt(1, project_id);
                ps2.setBlob(2, inputStream);
                ps2.executeUpdate();
            }

            // ⭐⭐⭐ END IMAGE CODE ⭐⭐⭐


            con.close();

            response.sendRedirect("customer.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}