package com.makeito.servlet;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;


public class DeliveryDetailsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String orderId = request.getParameter("order_id");

        String status = "Pending";

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/makeito_db",
                    "root",
                    "root");

            PreparedStatement ps = con.prepareStatement(
                    "SELECT status FROM delivery WHERE order_id=?");

            ps.setInt(1, Integer.parseInt(orderId));

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                status = rs.getString("status");
            }

            request.setAttribute("status", status);
            request.setAttribute("order_id", orderId);

            RequestDispatcher rd = request.getRequestDispatcher("deliveryTracking.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}