package com.makeito.servlet;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class ViewProjectsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Project> projectList = new ArrayList<>();

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/makeito_db",
                "root",
                "root"
            );

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM projects WHERE status='OPEN'"
            );

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                Project p = new Project();
                int projectId = rs.getInt("id");

                p.setId(projectId);
                p.setTitle(rs.getString("title"));
                p.setDescription(rs.getString("description"));
                p.setBudget(rs.getDouble("budget"));
                p.setCustomerEmail(rs.getString("customer_email"));

                // ⭐ FETCH IMAGE_ID FOR THIS PROJECT
                PreparedStatement psImg = con.prepareStatement(
                    "SELECT image_id FROM images_customer WHERE id=? LIMIT 1"
                );

                psImg.setInt(1, projectId);
                ResultSet rsImg = psImg.executeQuery();

                if (rsImg.next()) {
                    p.setImageId(rsImg.getInt("image_id"));
                } else {
                    p.setImageId(0); // no image available
                }

                projectList.add(p);
            }

            con.close();

            request.setAttribute("projects", projectList);
            RequestDispatcher rd = request.getRequestDispatcher("viewProjects.jsp");
            rd.forward(request, response);

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}