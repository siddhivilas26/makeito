package com.makeito.servlet;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/DeliveryUpdateServlet")
public class DeliveryUpdateServlet extends HttpServlet {

protected void doPost(HttpServletRequest request,HttpServletResponse response)
throws ServletException,IOException{

int orderId=Integer.parseInt(request.getParameter("order_id"));
String status=request.getParameter("status");

try{

Class.forName("com.mysql.cj.jdbc.Driver");

Connection con=DriverManager.getConnection(
"jdbc:mysql://localhost:3306/makeito_db","root","root");

PreparedStatement check=con.prepareStatement(
"SELECT * FROM delivery WHERE order_id=?"
);

check.setInt(1,orderId);

ResultSet rs=check.executeQuery();

if(rs.next()){

PreparedStatement update=con.prepareStatement(
"UPDATE delivery SET status=?, date=NOW() WHERE order_id=?"
);

update.setString(1,status);
update.setInt(2,orderId);

update.executeUpdate();

}
else{

PreparedStatement insert=con.prepareStatement(
"INSERT INTO delivery(order_id,status,date) VALUES(?,?,NOW())"
);

insert.setInt(1,orderId);
insert.setString(2,status);

insert.executeUpdate();

}

con.close();

response.sendRedirect("vendorOrders.jsp");

}

catch(Exception e){

e.printStackTrace();

}

}

}