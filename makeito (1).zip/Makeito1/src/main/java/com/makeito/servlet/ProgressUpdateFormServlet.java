package com.makeito.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


public class ProgressUpdateFormServlet extends HttpServlet {
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		 String status = request.getParameter("status");
	        int percent = Integer.parseInt(request.getParameter("complete_percentage"));
	        int id = Integer.parseInt(request.getParameter("id"));
	        
	        HttpSession session = request.getSession();
	        String customerEmail = (String) session.getAttribute("userEmail");
	        
	        try {

	            Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection con = DriverManager.getConnection(
	                "jdbc:mysql://localhost:3306/makeito_db",
	                "root",
	                "root"
	            );

	            PreparedStatement ps = con.prepareStatement(
	            	    "UPDATE orders SET status = ?, complete_percentage = ? WHERE id = ?"
	            	);

	            	ps.setString(1, status);
	            	ps.setInt(2, percent);
	            	ps.setInt(3, id);

	            	ps.executeUpdate();
	            con.close();

	            response.sendRedirect("vendor.jsp");

	        } catch (Exception e) {
	            e.printStackTrace();
	            response.getWriter().println(e.getMessage());
	        }
	        
		
	}

}
