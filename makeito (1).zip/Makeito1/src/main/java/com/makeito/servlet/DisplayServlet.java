package com.makeito.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.*;


public class DisplayServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("image_id");

        if (idParam == null) {
            response.getWriter().println("❌ image_id missing in URL.");
            return;
        }

        int id = Integer.parseInt(idParam);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/makeito_db",
                    "root",
                    "root"
            );

            PreparedStatement pst = con.prepareStatement(
                    "SELECT image FROM images_customer WHERE image_id=?"
            );

            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();

            if (!rs.next()) {
                response.getWriter().println("❌ No image found for id = " + id);
                return;
            }

            Blob blob = rs.getBlob("image");

            if (blob == null || blob.length() == 0) {
                response.getWriter().println("❌ Image blob is NULL or empty.");
                return;
            }

            response.setContentType("image/jpeg");

            OutputStream out = response.getOutputStream();
            out.write(blob.getBytes(1, (int) blob.length()));
            out.close();

        } catch (Exception e) {
            response.getWriter().println("❌ ERROR: " + e.getMessage());
        }
    }
}