package com.makeito.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class FinalPaymentServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
        int order_id = Integer.parseInt(request.getParameter("order_id"));
        String address = request.getParameter("deliveryAddress");
        String dateStr = request.getParameter("deliveryDate");
        String status="ORDER READY";

     // Convert String → java.sql.Date
     java.sql.Date deliveryDate = java.sql.Date.valueOf(dateStr);     
     Connection con = null;
        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/makeito_db",
                "root",
                "root"
            );

            // 🔎 Get selected quote details
            PreparedStatement getQuote = con.prepareStatement(
                "update payments set remaining_amount = 0 where order_id=?"
            );
            getQuote.setInt(1, order_id);
            getQuote.executeUpdate();

            PreparedStatement ps = con.prepareStatement(
            	    "INSERT INTO Delivery (order_id, status, date, address) VALUES (?, ?, ?, ?)"
            	);

            	ps.setInt(1, order_id);                // order_id
            	ps.setString(2, status);              // status
            	ps.setDate(3, deliveryDate);          // date (java.sql.Date)
            	ps.setString(4, address);             // address

            	ps.executeUpdate();
	
        con.close();

        response.sendRedirect("customerOrders.jsp");
        

    } catch(Exception e){
        e.printStackTrace();
    }

	
}
}
