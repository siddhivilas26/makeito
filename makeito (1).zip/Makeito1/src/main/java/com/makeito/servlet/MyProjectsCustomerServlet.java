package com.makeito.servlet;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class MyProjectsCustomerServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	 HttpSession session = request.getSession();
         String role = (String) session.getAttribute("userRole");
         String email = (String) session.getAttribute("userEmail");

        List<Project> projectList = new ArrayList<>();

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/makeito_db",
                "root",
                "root"
            );

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM projects WHERE customer_email=? "
            );
            ps.setString(1, email);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                Project p = new Project();
                p.setId(rs.getInt("id"));
                p.setTitle(rs.getString("title"));
                p.setDescription(rs.getString("description"));
                p.setBudget(rs.getDouble("budget"));
                p.setCustomerEmail(rs.getString("customer_email"));

                projectList.add(p);
            }

            con.close();

            request.setAttribute("projects", projectList);
            RequestDispatcher rd = request.getRequestDispatcher("MyProjectsCustomer.jsp");
            rd.forward(request, response);

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}
