package com.makeito.servlet;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class VendorOrdersServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String role = (String) session.getAttribute("userRole");
        String email = (String) session.getAttribute("userEmail");

        if(role == null || !role.equals("VENDOR")){
            response.sendRedirect("login.jsp");
            return;
        }

        List<Order> orderList = new ArrayList<>();

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/makeito_db",
                "root",
                "root"
            );

            PreparedStatement ps = con.prepareStatement(
                "SELECT o.*, p.title FROM orders o " +
                "JOIN projects p ON o.project_id = p.id " +
                "WHERE o.vendor_email=?"
            );

            ps.setString(1, email);

            ResultSet rs = ps.executeQuery();

            while(rs.next()){

                Order o = new Order();
                o.setId(rs.getInt("id"));
                o.setTitle(rs.getString("title"));
                o.setCustomerEmail(rs.getString("customer_email"));
                o.setVendorEmail(rs.getString("vendor_email"));
                o.setAmount(rs.getDouble("amount"));
                o.setStatus(rs.getString("status"));

                orderList.add(o);
            }

            con.close();

            request.setAttribute("orders", orderList);
            RequestDispatcher rd = request.getRequestDispatcher("vendorOrders.jsp");
            rd.forward(request, response);

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}
