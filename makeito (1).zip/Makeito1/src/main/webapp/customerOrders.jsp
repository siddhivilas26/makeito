<%@ page import="java.sql.*" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<%
    String role = (String) session.getAttribute("userRole");
    String email = (String) session.getAttribute("userEmail");

    if(role == null || !role.equals("CUSTOMER")){
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
<title>My Orders</title>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');

    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(135deg, #e3eeff, #f9faff);
        padding: 40px;
    }

    h1 {
        text-align: center;
        font-size: 32px;
        color: #222;
        margin-bottom: 40px;
        font-weight: 600;
    }

    .order-card {
        background: rgba(255, 255, 255, 0.75);
        backdrop-filter: blur(12px);
        padding: 25px;
        margin: 20px auto;
        width: 95%;
        max-width: 700px;
        border-radius: 16px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.10);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .order-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(0,0,0,0.15);
    }

    .order-title {
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 10px;
        color: #1a1a1a;
    }

    .detail-row {
        font-size: 15px;
        color: #444;
        margin: 5px 0;
    }

    .status-badge {
        display: inline-block;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 600;
        margin-top: 8px;
    }
    .pending { background:#ffe9b3; color:#b37a00; }
    .completed { background:#c8ffc8; color:#007a00; }
    .progress { background:#dfe7ff; color:#0035a1; }

    .progress-container {
        width: 100%;
        height: 14px;
        background: #e6e9f0;
        border-radius: 8px;
        margin-top: 15px;
        overflow: hidden;
    }

    .progress-fill {
        height: 100%;
        width: 0%;
        border-radius: 8px;
        transition: width 1s ease;
    }

    .low { background: #ffb14d; }
    .medium { background: #4da3ff; }
    .high { background: #54e07a; }

    .percent-text {
        font-size: 14px;
        font-weight: 600;
        margin-top: 5px;
        color: #333;
    }

    .pay-btn-link {
        display: inline-block;
        margin-top: 15px;
        padding: 10px 20px;
        background: #2ecc71;
        color: white;
        text-decoration: none;
        border-radius: 8px;
        font-weight: 600;
        font-size: 14px;
        transition: background 0.3s ease, transform 0.2s ease;
        box-shadow: 0 4px 6px rgba(46, 204, 113, 0.2);
    }

    .pay-btn-link:hover {
        background: #27ae60;
        transform: translateY(-2px);
    }

    .track-btn {
        margin-top: 15px;
        padding: 10px 18px;
        border: none;
        background: #4d79ff;
        color: white;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.2s ease;
    }

    .track-btn:hover {
        background: #3a5bd6;
    }

    /* MODAL */
    #deliveryModal {
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.6);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 5000;
    }

    .modal-box {
        background: white;
        width: 90%;
        max-width: 450px;
        padding: 25px;
        border-radius: 15px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.3);
        position: relative;
    }

    .close-btn {
        position: absolute;
        top: 8px;
        right: 12px;
        font-size: 18px;
        cursor: pointer;
        font-weight: bold;
    }
</style>
</head>
<body>

<h1>My Orders</h1>

<%
try {
    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/makeito_db", "root", "root"
    );

    PreparedStatement ps = con.prepareStatement(
        "SELECT o.*, p.title FROM orders o " +
        "JOIN projects p ON o.project_id = p.id " +
        "WHERE o.customer_email = ?"
    );
    ps.setString(1, email);
    ResultSet rs = ps.executeQuery();

    while(rs.next()){

        String status = rs.getString("status");
        int percent = rs.getInt("complete_percentage");
        double orderAmount = rs.getDouble("amount");
        int order_id = rs.getInt("id");

        String badgeClass =
            status.equals("PENDING") ? "pending" :
            status.equals("IN_PROGRESS") ? "progress" : "completed";

        String progressClass =
            percent <= 40 ? "low" :
            percent <= 80 ? "medium" : "high";
%>

<div class="order-card">

    <div class="order-title"><%= rs.getString("title") %></div>

    <div class="detail-row"><b>Vendor:</b> <%= rs.getString("vendor_email") %></div>
    <div class="detail-row"><b>Amount:</b> ₹<%= orderAmount %></div>

    <span class="status-badge <%= badgeClass %>"><%= status %></span>

    <div class="progress-container">
        <div class="progress-fill <%= progressClass %>" data-percent="<%= percent %>"></div>
    </div>

    <div class="percent-text"><%= percent %>% Completed</div>

    <!-- Track Delivery -->
   <button class="track-btn"
        onclick="window.location.href='DeliveryDetailsServlet?order_id=<%= order_id %>'">
    Track Delivery
</button>

    <% if (percent == 100 && status.equals("COMPLETED")) { %>
        <%
            PreparedStatement ps1 = con.prepareStatement(
                "SELECT remaining_amount FROM payments WHERE order_id=?"
            );
            ps1.setInt(1, order_id);
            ResultSet rs1 = ps1.executeQuery();
            while(rs1.next()){
                orderAmount = rs1.getFloat("remaining_amount");
            }
        %>

        <% if(orderAmount == 0){ %>
            <span style="display:inline-block; margin-top:15px; padding:10px 22px;
                          background:#6c7b8a; color:white; border-radius:8px;">
                ✔ PAID
            </span>
        <% } else { %>
            <a href="finalPaymet.jsp?remaining_amount=<%= orderAmount %>&order_id=<%= order_id %>"
               class="pay-btn-link">
                Proceed to Payment (₹<%= orderAmount %>)
            </a>
        <% } %>
    <% } %>

</div>

<%
    }
    con.close();
} catch(Exception e){
    e.printStackTrace();
}
%>


</body>
</html>