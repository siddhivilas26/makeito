<%@ page import="java.util.List" %>
<%@ page import="com.makeito.servlet.Project" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<%
    List<Project> projects = (List<Project>) request.getAttribute("projects");
    String email = (String) session.getAttribute("userEmail");
%>

<!DOCTYPE html>
<html>
<head>
<title>Vendor - Open Projects</title>

<style>
body {
    margin: 0;
    font-family: Arial;
    background-color: #f4f6f9;
}

.navbar {
    background-color: #1e272e;
    color: white;
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
}

.navbar a {
    color: white;
    text-decoration: none;
}

.container {
    padding: 40px;
}

.card {
    background: white;
    padding: 20px;
    margin-bottom: 25px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    transition: 0.3s;
}

.card:hover {
    transform: translateY(-5px);
}

.btn {
    display: inline-block;
    padding: 8px 15px;
    background: #27ae60;
    color: white;
    text-decoration: none;
    border-radius: 5px;
}
</style>

</head> 

<body>

<div class="navbar">
    <div>Makeito - Customer Panel</div>
    <div>
        <%= email %> |
        <a href="vendor.jsp">Dashboard</a> |
        <a href="LogoutServlet">Logout</a>
    </div>
</div>

<div class="container">

<h2>My Projects</h2>

<% if(projects != null && !projects.isEmpty()) {
       for(Project p : projects) { %>

    <div class="card">
        <h3><%= p.getTitle() %></h3>
        <p><%= p.getDescription() %></p>
        <p><b>Budget:</b> ₹<%= p.getBudget() %></p>
	
        
    </div>

<%     }
   } else { %>

    <p>No open projects available.</p>

<% } %>

</div>

</body>
</html>
