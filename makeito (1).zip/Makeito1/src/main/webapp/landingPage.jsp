<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Makeito – India’s 1st Fabrication & Furniture Marketplace</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>

/* ================= GLOBAL ================= */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Poppins', sans-serif;
  background: #F8F9FF;
  color: #333;
  line-height: 1.6;
}

.container {
  width: 90%;
  max-width: 1200px;
  margin: auto;
}

section {
  padding: 90px 0;
}

h2 {
  font-size: 40px;
  font-weight: 700;
}

h3 {
  font-size: 30px;
  font-weight: 600;
  color: #4B0066;
  margin-bottom: 50px;
  text-align: center;
}

/* ================= HEADER ================= */
header {
  background: #4B0066;
  padding: 18px 0;
  position: sticky;
  top: 0;
  z-index: 1000;
}

.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo {
  color: white;
  font-size: 22px;
  font-weight: 700;
}

nav a {
  color: white;
  margin-left: 30px;
  text-decoration: none;
  font-weight: 500;
  transition: 0.3s;
}

nav a:hover {
  color: #FF5757;
}

/* ================= HERO ================= */
.hero {
  background: linear-gradient(135deg, #4B0066, #6a1b9a);
  color: white;
  text-align: center;
  padding: 120px 20px;
  border-radius: 0 0 60px 60px;
}

.hero p {
  font-size: 18px;
  margin: 20px 0 35px 0;
  opacity: 0.9;
}

.hero-buttons {
  display: flex;
  justify-content: center;
  gap: 20px;
  flex-wrap: wrap;
}

/* ================= BUTTONS ================= */
.btn {
  padding: 14px 30px;
  border-radius: 12px;
  border: none;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-red {
  background: #FF5757;
  color: white;
  box-shadow: 0 8px 20px rgba(255,87,87,0.3);
}

.btn-red:hover {
  transform: translateY(-3px);
  box-shadow: 0 12px 25px rgba(255,87,87,0.5);
}

.btn-purple {
  background: white;
  color: #4B0066;
}

.btn-purple:hover {
  background: #f3f3f3;
}

/* ================= GRID ================= */
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px,1fr));
  gap: 30px;
}

.card {
  background: white;
  padding: 35px;
  border-radius: 20px;
  text-align: center;
  box-shadow: 0 10px 25px rgba(0,0,0,0.06);
  transition: all 0.3s ease;
}

.card:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 35px rgba(0,0,0,0.12);
}

.card img {
  width: 60px;
  margin-bottom: 20px;
}

.card h4 {
  margin-bottom: 10px;
  font-size: 18px;
  color: #4B0066;
}

/* ================= SERVICES ================= */
.service-card {
  background: #ffffff;
  border: 2px solid transparent;
  transition: 0.3s;
}

.service-card:hover {
  border: 2px solid #FF5757;
}

/* ================= TESTIMONIALS ================= */
.testimonial {
  text-align: left;
  border-left: 6px solid #4B0066;
}

.testimonial p {
  font-style: italic;
  margin-bottom: 15px;
}

/* ================= FOOTER ================= */
footer {
  background: #4B0066;
  color: white;
  text-align: center;
  padding: 50px 20px;
  border-radius: 50px 50px 0 0;
  margin-top: 80px;
}

footer p {
  margin: 8px 0;
  opacity: 0.9;
}

/* ================= RESPONSIVE ================= */
@media(max-width:768px) {
  h2 {
    font-size: 28px;
  }

  .hero {
    padding: 80px 20px;
  }

  nav {
    display: none;
  }
}

</style>
</head>
<body>

<!-- ================= HEADER ================= -->
<header>
  <div class="container navbar">
    <div class="logo">Makeito</div>
    <nav>
      <a href="#features">Features</a>
      <a href="#services">Services</a>
      <a href="#testimonials">Testimonials</a>
      <a href="#contact">Contact</a>
    </nav>
  </div>
</header>

<!-- ================= HERO ================= -->
<section class="hero">
  <div class="container">
    <h2>India’s 1st Marketplace for Fabrication & Furniture Services</h2>
    <p>Hire skilled fabricators, carpenters & rent professional tools — all in one place.</p>

    <div class="hero-buttons">
      <button class="btn btn-red"
        onclick="window.location.href='login.jsp'">
    Get Started
</button>

<button class="btn btn-purple"
        onclick="window.location.href='partnerRegister.jsp'">
    Join as Partner
</button>
    </div>
  </div>
</section>

<!-- ================= FEATURES ================= -->
<section id="features">
  <div class="container">
    <h3>Why Choose Makeito?</h3>
    <div class="grid">
      <div class="card">
        <img src="https://img.icons8.com/ios-filled/100/4B0066/worker-male.png">
        <h4>Verified Fabricators</h4>
        <p>Connect with trusted professionals for custom metal work.</p>
      </div>

      <div class="card">
        <img src="https://img.icons8.com/ios-filled/100/4B0066/hammer.png">
        <h4>Expert Carpenters</h4>
        <p>Book experienced carpenters for furniture & interiors.</p>
      </div>

      <div class="card">
        <img src="https://img.icons8.com/ios-filled/100/4B0066/toolbox.png">
        <h4>Tool Rentals</h4>
        <p>Rent high-quality tools without heavy investment.</p>
      </div>
    </div>
  </div>
</section>

<!-- ================= SERVICES ================= -->
<section id="services">
  <div class="container">
    <h3>Our Services</h3>
    <div class="grid">
      <div class="card service-card">Metal Fabrication</div>
      <div class="card service-card">Woodwork & Furniture</div>
      <div class="card service-card">Custom Craftsmanship</div>
      <div class="card service-card">On-Demand Skilled Services</div>
    </div>
  </div>
</section>

<!-- ================= TESTIMONIALS ================= -->
<section id="testimonials">
  <div class="container">
    <h3>What People Say</h3>
    <div class="grid">
      <div class="card testimonial">
        <p>“Makeito made it easy to find a skilled carpenter for my new home.”</p>
        <strong>- Mahendra, Pune</strong>
      </div>

      <div class="card testimonial">
        <p>“I rented welding tools at half the cost — game changer.”</p>
        <strong>- Raj Enterprises</strong>
      </div>

      <div class="card testimonial">
        <p>“Makeito helped me get consistent clients as a fabricator.”</p>
        <strong>- Sohial, Fabrication Shop</strong>
      </div>
    </div>
  </div>
</section>

<!-- ================= FOOTER ================= -->
<footer id="contact">
  <p>© 2025 Makeito | India’s 1st Fabrication & Furniture Marketplace</p>
  <p>Email: omchaudhari0709@gmail.com | +91-8766977328</p>
</footer>

</body>
</html>