<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Display Image</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
        }
        .container {
            width: 400px;
            padding: 20px;
            border: 1px solid #ddd;
            background: #f9f9f9;
            border-radius: 8px;
        }
        img {
            margin-top: 15px;
            border: 2px solid #000;
            width: 300px;
            height: 300px;
            object-fit: cover;
        }
        input, button {
            padding: 10px;
            margin-top: 10px;
            width: 100%;
            font-size: 16px;
        }
    </style>

</head>
<body>

<div class="container">
    <h2>Display Image From Database</h2>

    <form method="get" action="DisplayServlet">
        <label>Enter Image ID:</label>
        <input type="number" name="image_id" required>
        <button type="submit">Show Image</button>
    </form>

    <%
        String imageId = request.getParameter("image_id");
        if (imageId != null) {
    %>
        <h3>Showing Image ID: <%= imageId %></h3>
        <img src="DisplayServlet?image_id=<%= imageId %>" alt="Image Not Found">
    <% } %>

</div>

</body>
</html>