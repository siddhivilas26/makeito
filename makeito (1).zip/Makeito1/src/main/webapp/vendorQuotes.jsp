<%@ page import="java.sql.*" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String role = (String) session.getAttribute("userRole");
    String vendorEmail = (String) session.getAttribute("userEmail");

    if(role == null || !role.equals("VENDOR")){
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
<title>My Quotes</title>

<style>
body { font-family: Arial; background:#f4f6f9; padding:40px; }

.card {
    background:white;
    padding:20px;
    margin:20px 0;
    border-radius:8px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}
</style>
</head>

<body>

<h1>My Submitted Quotes</h1>

<%
try {

    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/makeito_db",
        "root",
        "root"
    );

    PreparedStatement ps = con.prepareStatement(
        "SELECT q.*, p.title FROM quotes q " +
        "JOIN projects p ON q.project_id = p.id " +
        "WHERE q.vendor_email = ?"
    );

    ps.setString(1, vendorEmail);

    ResultSet rs = ps.executeQuery();

    while(rs.next()){
%>

    <div class="card">
        <h3>Project: <%= rs.getString("title") %></h3>
        <p><b>Amount:</b> ₹<%= rs.getDouble("amount") %></p>
        <p><b>Status:</b> <%= rs.getString("status") %></p>
        <p><%= rs.getString("message") %></p>
    </div>

<%
    }

    con.close();

} catch(Exception e){
    e.printStackTrace();
}
%>

</body>
</html>
