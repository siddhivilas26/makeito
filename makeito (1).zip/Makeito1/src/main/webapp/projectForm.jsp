<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String email = (String) session.getAttribute("userEmail");
    if(email == null){
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Project | Makeito</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #7b2ff7, #f107a3);
            --bg-color: #f3f4ff;
            --card-bg: #ffffff;
            --text-main: #2c2c2c;
            --text-muted: #777;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: var(--bg-color);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .box {
            background: var(--card-bg);
            width: 100%;
            max-width: 500px;
            padding: 40px;
            border-radius: 25px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.08);
            position: relative;
            overflow: hidden;
        }

        /* Decorative top bar to match the theme */
        .box::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: var(--primary-gradient);
        }

        h2 {
            font-size: 26px;
            font-weight: 700;
            color: var(--text-main);
            margin-bottom: 10px;
            text-align: center;
        }

        p.info {
            font-size: 14px;
            color: var(--text-muted);
            text-align: center;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            color: #7b2ff7;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
            margin-left: 5px;
        }

        input, textarea {
            width: 100%;
            padding: 14px 18px;
            border: 1.5px solid #e1e4f0;
            border-radius: 12px;
            font-size: 14px;
            color: var(--text-main);
            background: #fafbff;
            transition: all 0.3s ease;
            outline: none;
        }

        input:focus, textarea:focus {
            border-color: #7b2ff7;
            background: #fff;
            box-shadow: 0 8px 20px rgba(123, 47, 247, 0.1);
        }

        textarea {
            height: 120px;
            resize: none;
        }

        button {
            width: 100%;
            padding: 15px;
            margin-top: 10px;
            border: none;
            border-radius: 12px;
            background: var(--primary-gradient);
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 10px 20px rgba(123, 47, 247, 0.2);
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 30px rgba(123, 47, 247, 0.3);
            filter: brightness(1.05);
        }

        button:active {
            transform: translateY(0);
        }

        .back-btn {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 13px;
            color: var(--text-muted);
            text-decoration: none;
            transition: 0.3s;
        }

        .back-btn:hover {
            color: #7b2ff7;
        }
    </style>
</head>

<body>

<div class="box">
    <h2>Submit New Project</h2>
    <p class="info">Tell us what you want to create and we'll find the best maker.</p>

    <form action="ProjectServlet" method="post">
        <div class="form-group">
            <label>Project Title</label>
            <input type="text" name="title" placeholder="e.g. Custom Oak Bookshelf" required>
        </div>

        <div class="form-group">
            <label>Description</label>
            <textarea name="description" placeholder="Dimensions, material preferences, and specific details..." required></textarea>
        </div>

        <div class="form-group">
            <label>Estimated Budget ($)</label>
            <input type="number" name="budget" placeholder="Enter amount" required>
        </div>

        <button type="submit">Publish Project</button>
    </form>
    
    <a href="customerDashboard.jsp" class="back-btn">← Back to Dashboard</a>
</div>

</body>
</html>