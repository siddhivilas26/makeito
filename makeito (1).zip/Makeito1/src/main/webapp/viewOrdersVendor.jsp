<%@ page import="java.util.*" %>

<%
    Object obj = request.getAttribute("orders");
    List<List<Object>> list = null;

    if (obj instanceof List) {
        list = (List<List<Object>>) obj;
    }

    List<Object> row = (list != null && !list.isEmpty()) ? list.get(0) : null;
%>

<!DOCTYPE html>
<html>
<head>
<title>Project Details</title>

<style>
    body {
        font-family: "Poppins", sans-serif;
        background: #f5f6fa;
        margin: 0;
        padding: 0;
    }

    .container {
        width: 92%;
        max-width: 750px;
        margin: 40px auto;
        background: #fff;
        border-radius: 16px;
        padding: 30px;
        box-shadow: 0 6px 22px rgba(0,0,0,0.12);
    }

    .image-box {
        width: 100%;
        height: 320px;
        border-radius: 14px;
        overflow: hidden;
        margin-bottom: 25px;
        background: #eee;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .image-box img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        cursor: pointer;
        transition: 0.3s ease-in-out;
    }
    .image-box img:hover {
        transform: scale(1.03);
    }

    .no-image {
        color: #777;
        font-size: 20px;
    }

    .details h2 {
        margin: 5px 0 12px 0;
        font-size: 28px;
        color: #222;
        font-weight: 600;
    }

    .details p {
        margin: 10px 0;
        font-size: 17px;
        color: #444;
        line-height: 1.5;
    }

    .details strong {
        color: #000;
        font-weight: 600;
    }

    /* Modal */
    .modal {
        display: none;
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.85);
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }

    .modal img {
        max-width: 90%;
        max-height: 90%;
        border-radius: 12px;
        box-shadow: 0 0 15px rgba(0,0,0,0.3);
    }

    .modal.show {
        display: flex;
    }
</style>

<script>
    function openModal(imgUrl) {
        document.getElementById("modalImage").src = imgUrl;
        document.getElementById("imgModal").classList.add("show");
    }
    function closeModal() {
        document.getElementById("imgModal").classList.remove("show");
    }
</script>

</head>
<body>

<div class="container">

<% if (row != null) {
    int id = (int) row.get(0);
    String title = row.get(1).toString();
    String desc = row.get(2).toString();
    String email = row.get(3).toString();
    String created = row.get(4).toString();
    int imageId = Integer.parseInt(row.get(5).toString());
%>

    <!-- IMAGE BLOCK -->
    <div class="image-box">
        <% if (imageId > 0) { %>
            <img src="DisplayServlet?image_id=<%= imageId %>"
                 onclick="openModal('DisplayServlet?image_id=<%= imageId %>')">
        <% } else { %>
            <span class="no-image">No Image Available</span>
        <% } %>
    </div>

    <!-- DETAILS -->
    <div class="details">
        <h2><%= title %></h2>
        <p><strong>Description:</strong> <%= desc %></p>
        <p><strong>Customer Email:</strong> <%= email %></p>
        <p><strong>Created At:</strong> <%= created %></p>
        <p><strong>Project ID:</strong> <%= id %></p>
    </div>

<% } %>

</div>

<!-- MODAL POPUP -->
<div id="imgModal" class="modal" onclick="closeModal()">
    <img id="modalImage">
</div>

</body>
</html>