<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%
    String email = (String) session.getAttribute("userEmail");
    if(email == null){
        response.sendRedirect("login.jsp");
        return;
    }

    String amountStr = request.getParameter("remaining_amount");
    String order_id = request.getParameter("order_id");
    String displayAmount = (amountStr != null) ? amountStr : "0.00";
%>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Secure Checkout</title>

<style>
    body {
        font-family: 'Segoe UI';
        background: #f2f4f8;
        margin: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    .checkout-container {
        width: 100%;
        max-width: 800px;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        overflow: hidden;
    }

    .checkout-header {
        background: #1a1a1a;
        color: #fff;
        padding: 20px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .checkout-body { display: flex; }

    .payment-sidebar {
        width: 30%;
        background: #f9fbfc;
        border-right: 1px solid #ddd;
    }

    .payment-method-tab {
        padding: 18px;
        cursor: pointer;
        border-bottom: 1px solid #e1e8ed;
        color: #555;
        font-weight: 500;
        transition: 0.2s;
    }

    .payment-method-tab.active {
        background: #fff;
        border-left: 4px solid #3498db;
        color: #3498db;
        font-weight: 600;
    }

    .payment-main {
        width: 70%;
        padding: 30px;
    }

    .tab-content { display: none; }
    .tab-content.active { display: block; }

    .form-group { margin-bottom: 18px; }
    label { font-weight: 600; font-size: 14px; display: block; margin-bottom: 5px; }

    input, select {
        width: 100%;
        padding: 12px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 15px;
    }

    .pay-btn {
        width: 100%;
        padding: 14px;
        background: #2ecc71;
        border: none;
        color: #fff;
        font-size: 18px;
        border-radius: 6px;
        cursor: pointer;
        margin-top: 25px;
    }
</style>

</head>
<body>

<div class="checkout-container">

    <!-- HEADER -->
    <div class="checkout-header">
        <h2>Makeito Secure Checkout</h2>
        <div class="amount">₹<%= displayAmount %></div>
    </div>

    <!-- PAYMENT FORM -->
    <form action="FinalPaymentServlet" method="get">

        <!-- Hidden fields -->
        <input type="hidden" name="quoteId" value="<%= request.getParameter("quoteId") %>">
        <input type="hidden" name="projectId" value="<%= request.getParameter("projectId") %>">
        <input type="hidden" name="advanceAmount" value="<%= displayAmount %>">
        <input type="hidden" name="amount" value="<%= request.getParameter("amount") %>">
        <input type="hidden" name="order_id" value="<%= request.getParameter("order_id") %>">
        <input type="hidden" name="paymentMethod" id="selectedPaymentMethod" value="UPI">

        <div class="checkout-body">

            <!-- PAYMENT TABS -->
            <div class="payment-sidebar">
                <div class="payment-method-tab active" onclick="switchTab('upi','UPI',this)">UPI Apps</div>
                <div class="payment-method-tab" onclick="switchTab('card','CARD',this)">Credit / Debit Card</div>
                <div class="payment-method-tab" onclick="switchTab('netbanking','NETBANKING',this)">Net Banking</div>
                <div class="payment-method-tab" onclick="switchTab('cod','COD',this)">Cash on Delivery</div>
            </div>

            <!-- PAYMENT CONTENT -->
            <div class="payment-main">

                <!-- UPI -->
                <div id="upi" class="tab-content active">
                    <div class="form-group">
                        <label>UPI ID</label>
                        <input type="text" name="upiId" placeholder="yourname@bank">
                    </div>
                </div>

                <!-- CARD -->
                <div id="card" class="tab-content">
                    <div class="form-group">
                        <label>Card Number</label>
                        <input type="text" name="cardNumber" placeholder="0000 0000 0000 0000">
                    </div>
                </div>

                <!-- NET BANKING -->
                <div id="netbanking" class="tab-content">
                    <div class="form-group">
                        <label>Select Bank</label>
                        <select name="bankName">
                            <option value="">Choose Bank</option>
                            <option value="HDFC">HDFC Bank</option>
                            <option value="SBI">State Bank of India</option>
                            <option value="ICICI">ICICI Bank</option>
                        </select>
                    </div>
                </div>

                <!-- COD -->
                <div id="cod" class="tab-content">
                    <p>Pay at the time of delivery.</p>
                </div>

                <!-- COMMON FIELDS (NEWLY ADDED) -->
                <div class="form-group">
                    <label>Delivery Date</label>
                    <input type="date" name="deliveryDate" required>
                </div>

                <div class="form-group">
                    <label>Delivery Address</label>
                    <input type="text" name="deliveryAddress" placeholder="Enter full delivery address" required>
                </div>

                <button class="pay-btn" type="submit">Pay ₹<%= displayAmount %></button>

            </div>
        </div>
    </form>

</div>

<script>
function switchTab(tabId, method, element) {
    document.querySelectorAll(".tab-content").forEach(t => t.classList.remove("active"));
    document.getElementById(tabId).classList.add("active");

    document.querySelectorAll(".payment-method-tab").forEach(t => t.classList.remove("active"));
    element.classList.add("active");

    document.getElementById("selectedPaymentMethod").value = method;

    let btn = document.querySelector(".pay-btn");
    btn.innerHTML = method === "COD" ? "Place Order" : "Pay ₹<%= displayAmount %>";
}
</script>

</body>
</html>