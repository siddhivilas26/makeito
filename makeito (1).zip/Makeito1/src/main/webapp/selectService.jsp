<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Explore Our Services</title>

    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" rel="stylesheet"/>

    <style>
        body {
            background-color: #f4f6ff;
            font-family: Arial, sans-serif;
        }
        .navbar {
            background-color: #5e068a;
        }
        .navbar a {
            color: white !important;
            font-weight: 500;
        }
        .container-box {
            background: white;
            border-radius: 20px;
            padding: 40px;
            margin-top: 40px;
            box-shadow: 0px 2px 10px rgba(0,0,0,0.1);
        }
        .service-card {
            background: white;
            border-radius: 18px;
            padding: 25px;
            text-align: center;
            box-shadow: 0px 2px 8px rgba(0,0,0,0.15);
            transition: 0.3s;
            cursor: pointer;
            border: none;
            width: 100%;
        }
        .service-card:hover {
            transform: translateY(-4px);
            box-shadow: 0px 4px 15px rgba(0,0,0,0.2);
        }
        .service-icon {
            font-size: 48px;
            margin-bottom: 10px;
            color: #5e068a;
        }
        .back-btn {
            background: #5e068a;
            color: white;
            border-radius: 8px;
            padding: 8px 15px;
            font-size: 15px;
        }
        .back-btn:hover {
            background: #4a046f;
        }

        /* Remove form button default styling */
        .form-btn {
            background: none;
            border: none;
            padding: 0;
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg px-4">
    <a class="navbar-brand text-white fw-bold" href="#">Makeito</a>
    <div class="ms-auto">
        <a class="nav-link d-inline me-3" href="#">Features</a>
        <a class="nav-link d-inline me-3" href="#">Services</a>
        <a class="nav-link d-inline me-3" href="#">Testimonials</a>
        <a class="nav-link d-inline" href="#">Contact</a>
    </div>
</nav>

<!-- MAIN CONTENT -->
<div class="container container-box">

    <!-- Back Button -->
    <a href="login.jsp" class="btn back-btn mb-3">
        ← Back
    </a>

    <h3 class="fw-bold mb-4">Explore Our Services</h3>

    <div class="row g-4">

        <!-- Fabrication -->
        <div class="col-md-4">
            <form action="customer.jsp" method="post">
                <input type="hidden" name="service" value="Fabrication">
                <button type="submit" class="form-btn w-100">
                    <div class="service-card">
                        <span class="material-symbols-rounded service-icon">build</span>
                        <h5 class="fw-bold">Fabrication</h5>
                        <p>From ₹5000</p>
                    </div>
                </button>
            </form>
        </div>

        <!-- Carpentry -->
        <div class="col-md-4">
            <form action="customer.jsp" method="post">
                <input type="hidden" name="service" value="Carpentry">
                <button type="submit" class="form-btn w-100">
                    <div class="service-card">
                        <span class="material-symbols-rounded service-icon">chair</span>
                        <h5 class="fw-bold">Carpentry</h5>
                        <p>From ₹2000</p>
                    </div>
                </button>
            </form>
        </div>

        <!-- Welding -->
        <div class="col-md-4">
            <form action="customer.jsp" method="post">
                <input type="hidden" name="service" value="Welding">
                <button type="submit" class="form-btn w-100">
                    <div class="service-card">
                        <span class="material-symbols-rounded service-icon">handyman</span>
                        <h5 class="fw-bold">Welding</h5>
                        <p>From ₹1500</p>
                    </div>
                </button>
            </form>
        </div>

        <!-- Furniture Making -->
        <div class="col-md-4">
            <form action="customer.jsp" method="post">
                <input type="hidden" name="service" value="Furniture Making">
                <button type="submit" class="form-btn w-100">
                    <div class="service-card">
                        <span class="material-symbols-rounded service-icon">luggage</span>
                        <h5 class="fw-bold">Furniture Making</h5>
                        <p>From ₹7000</p>
                    </div>
                </button>
            </form>
        </div>

        <!-- Electricians -->
        <div class="col-md-4">
            <form action="customer.jsp" method="post">
                <input type="hidden" name="service" value="Electricians">
                <button type="submit" class="form-btn w-100">
                    <div class="service-card">
                        <span class="material-symbols-rounded service-icon">lightbulb</span>
                        <h5 class="fw-bold">Electricians</h5>
                        <p>From ₹500</p>
                    </div>
                </button>
            </form>
        </div>

        <!-- Painters -->
        <div class="col-md-4">
            <form action="customer.jsp" method="post">
                <input type="hidden" name="service" value="Painters">
                <button type="submit" class="form-btn w-100">
                    <div class="service-card">
                        <span class="material-symbols-rounded service-icon">palette</span>
                        <h5 class="fw-bold">Painters</h5>
                        <p>From ₹2000</p>
                    </div>
                </button>
            </form>
        </div>

        <!-- Tool Rentals -->
        <div class="col-md-4">
            <form action="customer.jsp" method="post">
                <input type="hidden" name="service" value="Tool Rentals">
                <button type="submit" class="form-btn w-100">
                    <div class="service-card">
                        <span class="material-symbols-rounded service-icon">settings</span>
                        <h5 class="fw-bold">Tool Rentals</h5>
                        <p>₹300/day</p>
                    </div>
                </button>
            </form>
        </div>

    </div>
</div>

</body>
</html>