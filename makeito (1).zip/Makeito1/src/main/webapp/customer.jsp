<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String role = (String) session.getAttribute("userRole");
    String email = (String) session.getAttribute("userEmail");

    if(role == null || !role.equals("CUSTOMER")){
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
<title>Customer Dashboard | Makeito</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
/* ---------------------- GLOBAL ---------------------- */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: "Poppins", sans-serif;
    background: linear-gradient(135deg, #f8f9ff, #f1f3ff);
    color: #2c2c2c;
    overflow-x: hidden;
}

/* ---------------------- TOPBAR ---------------------- */
.topbar {
    position: sticky;
    top: 0;
    z-index: 1000;
    backdrop-filter: blur(15px);
    background: rgba(75, 0, 125, 0.85);
    padding: 15px 60px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: white;
    box-shadow: 0 4px 20px rgba(0,0,0,0.1);
}

.logo {
    font-size: 24px;
    font-weight: 700;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.right {
    display: flex;
    align-items: center;
    gap: 25px;
    font-size: 14px;
}

.right span { opacity: 0.9; }

.right a {
    text-decoration: none;
    color: #fff;
    background: rgba(255,255,255,0.15);
    padding: 8px 18px;
    border-radius: 50px;
    transition: 0.3s;
    font-weight: 500;
}

.right a:hover {
    background: #f107a3;
}

/* ---------------------- SEARCH ---------------------- */
.header-row {
    padding: 30px 60px 10px;
    display: flex;
    justify-content: flex-end;
}

.search-box {
    width: 380px;
    background: white;
    padding: 12px 20px;
    border-radius: 50px;
    display: flex;
    align-items: center;
    box-shadow: 0 10px 25px rgba(0,0,0,0.05);
    border: 1px solid #eee;
}

.search-box input {
    border: none;
    outline: none;
    width: 100%;
    margin-left: 10px;
    font-size: 14px;
}

/* ---------------------- BANNER ---------------------- */
.banner {
    width: 90%;
    margin: 20px auto;
    border-radius: 25px;
    overflow: hidden;
    height: 400px;
    position: relative;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
}

.banner img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    filter: brightness(0.85);
    transition: transform 0.8s ease;
}

.banner:hover img {
    transform: scale(1.05);
    filter: brightness(1);
}

/* Glass Overlay on Banner */
.banner-content {
    position: absolute;
    bottom: 40px;
    left: 40px;
    color: white;
    text-shadow: 0 2px 10px rgba(0,0,0,0.3);
}

.banner-content h1 {
    font-size: 42px;
    margin-bottom: 5px;
}

/* ---------------------- CATEGORY TABS ---------------------- */
.category-tabs {
    width: 90%;
    margin: 30px auto;
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
}

.tab {
    padding: 10px 22px;
    background: white;
    border-radius: 50px;
    border: 1px solid #eef0f7;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    transition: 0.3s;
    box-shadow: 0 4px 6px rgba(0,0,0,0.02);
}

.tab:hover {
    background: #7b2ff7;
    color: white;
    transform: translateY(-2px);
}

/* ---------------------- TAG ROW ---------------------- */
.tag-row {
    width: 90%;
    margin: 0 auto 30px;
    display: flex;
    gap: 12px;
}

.tag-row span {
    background: #ebedff;
    color: #4b007d;
    padding: 6px 15px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

/* ---------------------- SECTION TITLE ---------------------- */
.section-title {
    width: 90%;
    margin: 40px auto 20px;
    font-size: 24px;
    font-weight: 700;
    color: #1a1a1a;
    border-left: 5px solid #7b2ff7;
    padding-left: 15px;
}

/* ---------------------- FEATURE GRID ---------------------- */
.feature-grid {
    width: 90%;
    margin: 20px auto 80px;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 25px;
}

.feature-card {
    background: white;
    padding: 40px 20px;
    border-radius: 20px;
    text-align: center;
    transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    border: 1px solid rgba(0,0,0,0.03);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.feature-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 25px 50px -15px rgba(123, 47, 247, 0.3);
}

.icon {
    font-size: 44px;
    margin-bottom: 20px;
    background: linear-gradient(135deg, #7b2ff7, #f107a3);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.feature-card button {
    border: none;
    background: none;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    color: #333;
    padding: 10px;
}

/* ---------------------- RESPONSIVE ---------------------- */
@media (max-width: 768px) {
    .topbar { padding: 15px 20px; }
    .header-row { justify-content: center; padding: 20px; }
    .search-box { width: 100%; }
    .banner { height: 250px; }
    .banner-content h1 { font-size: 24px; }
}
</style>
</head>

<body>

<div class="topbar">
    <div class="logo">Makeito</div>
    <div class="right">
        <span>Logged in as: <b><%= email %></b></span>
        <a href="LogoutServlet">Logout</a>
    </div>
</div>

<div class="header-row">
    <div class="search-box">
        🔍 <input type="text" placeholder="Search for shops, items, designs...">
    </div>
</div>

<div class="banner">
    <img src="https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&q=80&w=1470" alt="Precision Manufacturing">
    <div class="banner-content">
        <h1>Precision in every detail.</h1>
        <p>Your one-stop shop for professional fabrication.</p>
    </div>
</div>

<div class="category-tabs">
    <div class="tab">Metal Work</div>
    <div class="tab">Wooden Work</div>
    <div class="tab">Fabrication</div>
    <div class="tab">Custom Designs</div>
    <div class="tab">3D Printing</div>
</div>

<div class="tag-row">
    <span>Quick Quote</span>
    <span>Verified Makers</span>
    <span>Bulk Orders</span>
</div>

<div class="section-title">Design Your Future</div>

<div class="feature-grid">

    <form action="MakeImaginaryObjectServlet" method="post" class="feature-card">
        <div class="icon">🪄</div>
        <button type="submit">Make Imaginary Objects</button>
    </form>

    <form action="imageProjectUpload.jsp" method="post" class="feature-card">
        <div class="icon">📸</div>
        <button type="submit">Upload Design Images</button>
    </form>

    <form action="projectForm.jsp" method="post" class="feature-card">
        <div class="icon">🛠️</div>
        <button type="submit">Submit New Project</button>
    </form>

    <form action="MyProjectsCustomerServlet" method="get" class="feature-card">
        <div class="icon">📂</div>
        <button type="submit">My Projects</button>
    </form>

    <form action="viewQuotes.jsp" method="post" class="feature-card">
        <div class="icon">💸</div>
        <button type="submit">My Quotes</button>
    </form>

    <form action="customerOrders.jsp" method="post" class="feature-card">
        <div class="icon">📦</div>
        <button type="submit">My Orders</button>
    </form>

</div>

</body>
</html>