<%@ page contentType="text/html;charset=UTF-8" %>

<%
String status = (String)request.getAttribute("status");
String orderId = (String)request.getAttribute("order_id");
%>

<!DOCTYPE html>
<html>
<head>

<title>Track Delivery</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">

<style>

body{
font-family:'Inter',sans-serif;
background:#f3f4f6;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

.card{
background:white;
padding:40px;
border-radius:14px;
width:500px;
box-shadow:0 10px 30px rgba(0,0,0,0.1);
}

h2{
margin-bottom:25px;
}

.timeline{
display:flex;
flex-direction:column;
gap:20px;
}

.step{
display:flex;
align-items:center;
gap:15px;
}

.circle{
width:18px;
height:18px;
border-radius:50%;
background:#d1d5db;
}

.active{
background:#10b981;
}

.line{
height:40px;
width:2px;
background:#e5e7eb;
margin-left:8px;
}

.label{
font-size:15px;
}

</style>

</head>

<body>

<div class="card">

<h2>Track Order #<%=orderId%></h2>

<div class="timeline">

<div class="step">
<div class="circle <%= status.equals("Packed") || status.equals("Shipped") || status.equals("Out for Delivery") || status.equals("Delivered") ? "active":"" %>"></div>
<div class="label">Packed</div>
</div>

<div class="line"></div>

<div class="step">
<div class="circle <%= status.equals("Shipped") || status.equals("Out for Delivery") || status.equals("Delivered") ? "active":"" %>"></div>
<div class="label">Shipped</div>
</div>

<div class="line"></div>

<div class="step">
<div class="circle <%= status.equals("Out for Delivery") || status.equals("Delivered") ? "active":"" %>"></div>
<div class="label">Out for Delivery</div>
</div>

<div class="line"></div>

<div class="step">
<div class="circle <%= status.equals("Delivered") ? "active":"" %>"></div>
<div class="label">Delivered</div>
</div>

</div>

</div>

</body>
</html>