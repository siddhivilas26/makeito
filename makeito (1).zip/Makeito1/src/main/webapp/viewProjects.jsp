<%@ page import="java.util.List" %>
<%@ page import="com.makeito.servlet.Project" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<%
    List<Project> projects = (List<Project>) request.getAttribute("projects");
    String email = (String) session.getAttribute("userEmail");
%>

<!DOCTYPE html>
<html>
<head>
<title>Vendor - Open Projects</title>

<style>
/* ===== GLOBAL ===== */
body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #ebeef5, #f8f9fb);
}

/* ===== NAVBAR ===== */
.navbar {
    background: linear-gradient(90deg, #182848, #4b6cb7);
    color: white;
    padding: 18px 35px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 18px;
}

.navbar a {
    color: #ffd369;
    margin-left: 15px;
    text-decoration: none;
    font-weight: 600;
}

.navbar a:hover {
    color: #ffffff;
}

/* ===== CONTAINER & GRID ===== */
.container {
    padding: 40px;
}

.grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(360px, 1fr));
    gap: 28px;
}

/* ===== CARD (Glass UI) ===== */
.card {
    background: rgba(255,255,255,0.8);
    padding: 20px;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    backdrop-filter: blur(10px);
    transition: transform .25s ease, box-shadow .25s ease;
}

.card:hover {
    transform: translateY(-6px);
    box-shadow: 0 18px 40px rgba(0,0,0,0.2);
}

.project-image {
    width: 100%;
    height: 220px;
    border-radius: 12px;
    object-fit: cover;
    cursor: zoom-in;
    margin-bottom: 12px;
}

/* TEXT */
.card h3 {
    margin: 8px 0;
    color: #2c3e50;
}

.card p {
    color: #555;
}

/* BUTTON */
.btn {
    display: inline-block;
    padding: 10px 20px;
    background: linear-gradient(90deg, #16a085, #27ae60);
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
    margin-top: 10px;
    box-shadow: 0px 5px 15px rgba(20, 150, 90, 0.3);
}

.btn:hover {
    background: linear-gradient(90deg, #1abc9c, #2ecc71);
}

/* ===== IMAGE MODAL ===== */
#imgModal {
    display: none;
    position: fixed;
    z-index: 99999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(10,10,10,0.95);
    text-align: center;
    padding-top: 50px;
}

#modalImg {
    max-width: 92%;
    max-height: 85%;
    border-radius: 10px;
    box-shadow: 0 0 25px rgba(255,255,255,0.3);
}

.closeBtn {
    position: absolute;
    top: 15px;
    right: 30px;
    font-size: 45px;
    color: white;
    cursor: pointer;
    font-weight: bold;
}
</style>

<script>
// OPEN MODAL
function openModal(src) {
    document.getElementById("imgModal").style.display = "block";
    document.getElementById("modalImg").src = src;
}
// CLOSE MODAL
function closeModal() {
    document.getElementById("imgModal").style.display = "none";
}
</script>

</head>

<body>

<!-- MODAL -->
<div id="imgModal" onclick="closeModal()">
    <span class="closeBtn">&times;</span>
    <img id="modalImg">
</div>

<div class="navbar">
    <div><b>Makeito Vendor Panel</b></div>
    <div>
        <%= email %>
        <a href="vendor.jsp">Dashboard</a>
        <a href="LogoutServlet">Logout</a>
    </div>
</div>

<div class="container">

<h2 style="margin-bottom: 25px; color:#2c3e50;">Available Projects</h2>

<div class="grid">

<% if(projects != null && !projects.isEmpty()) {
       for(Project p : projects) { %>

    <div class="card">

        <!-- ⭐ SHOW IMAGE ONLY IF AVAILABLE -->
        <% if (p.getImageId() > 0) { %>
            <img class="project-image"
                 src="DisplayServlet?image_id=<%= p.getImageId() %>"
                 onclick="openModal('DisplayServlet?image_id=<%= p.getImageId() %>')">
        <% } %>

        <h3><%= p.getTitle() %></h3>
        <p><%= p.getDescription() %></p>
        <p><b>Budget:</b> ₹<%= p.getBudget() %></p>

        <a class="btn" href="quoteForm.jsp?projectId=<%= p.getId() %>">Send Quote</a>

    </div>

<%     }
   } else { %>

    <p>No open projects available.</p>

<% } %>

</div>
</div>

</body>
</html>