<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String role = (String) session.getAttribute("userRole");
    String email = (String) session.getAttribute("userEmail");
    if(role == null || !role.equals("VENDOR")){
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
<title>Makeito - Vendor Dashboard</title>
<style>
    /* =========================================
       MAKEITO DESIGN SYSTEM - Shared Styles
       ========================================= */

    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

    :root {
        --primary: #4B007D;
        --primary-dark: #360060;
        --primary-light: #7b2ff7;
        --accent: #ff6f61;
        --accent-hover: #ff4e3d;
        --bg: #f5f6fa;
        --card-bg: #ffffff;
        --text-main: #1a1a2e;
        --text-muted: #6b7280;
        --border: #e5e7eb;
        --shadow: 0 4px 24px rgba(75, 0, 125, 0.08);
        --shadow-hover: 0 8px 32px rgba(75, 0, 125, 0.18);
        --radius-card: 18px;
        --radius-btn: 10px;
        --radius-input: 10px;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
        font-family: 'Poppins', Arial, sans-serif;
        background: var(--bg);
        color: var(--text-main);
        min-height: 100vh;
    }

    /* ---- NAVBAR ---- */
    .mk-navbar {
        background: var(--primary);
        padding: 0 48px;
        height: 64px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: sticky;
        top: 0;
        z-index: 100;
        box-shadow: 0 2px 12px rgba(0,0,0,0.18);
    }

    .mk-navbar .logo {
        font-size: 22px;
        font-weight: 700;
        color: white;
        letter-spacing: 1px;
    }

    .mk-navbar .logo span { color: #ffb3fe; }

    .mk-navbar .nav-links { display: flex; align-items: center; gap: 28px; }

    .mk-navbar .nav-links a {
        color: rgba(255,255,255,0.85);
        text-decoration: none;
        font-size: 14px;
        font-weight: 500;
        transition: color 0.2s;
    }

    .mk-navbar .nav-links a:hover { color: #fff; }

    .mk-navbar .nav-user {
        display: flex;
        align-items: center;
        gap: 16px;
        font-size: 13px;
        color: #e0c6ff;
    }

    .mk-navbar .nav-user .user-badge {
        background: rgba(255,255,255,0.15);
        border-radius: 20px;
        padding: 5px 14px;
        font-size: 12px;
        color: white;
        font-weight: 500;
    }

    .mk-navbar .nav-user a {
        color: #ffb3fe;
        text-decoration: none;
        font-weight: 600;
        font-size: 13px;
    }

    .mk-navbar .nav-user a:hover { color: white; }

    /* ---- BUTTONS ---- */
    .btn-primary {
        background: var(--accent);
        color: white;
        border: none;
        border-radius: var(--radius-btn);
        padding: 12px 28px;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.2s, transform 0.15s;
        text-decoration: none;
        display: inline-block;
    }

    .btn-primary:hover {
        background: var(--accent-hover);
        transform: translateY(-1px);
        color: white;
    }

    .btn-purple {
        background: var(--primary);
        color: white;
        border: none;
        border-radius: var(--radius-btn);
        padding: 10px 22px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.2s, transform 0.15s;
        text-decoration: none;
        display: inline-block;
    }

    .btn-purple:hover {
        background: var(--primary-dark);
        color: white;
        transform: translateY(-1px);
    }

    .btn-green {
        background: #10b981;
        color: white;
        border: none;
        border-radius: var(--radius-btn);
        padding: 10px 22px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.2s;
        text-decoration: none;
        display: inline-block;
    }

    .btn-green:hover { background: #059669; color: white; }

    .btn-outline {
        background: transparent;
        color: var(--primary);
        border: 2px solid var(--primary);
        border-radius: var(--radius-btn);
        padding: 8px 20px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        text-decoration: none;
        display: inline-block;
    }

    .btn-outline:hover {
        background: var(--primary);
        color: white;
    }

    /* ---- CARDS ---- */
    .mk-card {
        background: var(--card-bg);
        border-radius: var(--radius-card);
        box-shadow: var(--shadow);
        border: 1px solid var(--border);
        padding: 28px;
        transition: box-shadow 0.25s, transform 0.25s;
    }

    .mk-card:hover {
        box-shadow: var(--shadow-hover);
        transform: translateY(-4px);
    }

    /* ---- INPUTS ---- */
    .mk-input {
        width: 100%;
        padding: 13px 16px;
        border: 1.5px solid var(--border);
        border-radius: var(--radius-input);
        font-family: 'Poppins', sans-serif;
        font-size: 14px;
        background: #fafafa;
        color: var(--text-main);
        outline: none;
        transition: border-color 0.2s, box-shadow 0.2s;
    }

    .mk-input:focus {
        border-color: var(--primary-light);
        box-shadow: 0 0 0 3px rgba(123,47,247,0.1);
        background: white;
    }

    .mk-label {
        display: block;
        font-size: 13px;
        font-weight: 600;
        color: var(--text-main);
        margin-bottom: 6px;
        margin-top: 16px;
    }

    /* ---- STATUS BADGES ---- */
    .badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.3px;
    }

    .badge-open { background: #d1fae5; color: #065f46; }
    .badge-closed { background: #fee2e2; color: #991b1b; }
    .badge-pending { background: #fef3c7; color: #92400e; }
    .badge-accepted { background: #d1fae5; color: #065f46; }
    .badge-inprogress { background: #dbeafe; color: #1e40af; }
    .badge-completed { background: #e0e7ff; color: #3730a3; }

    /* ---- PAGE WRAPPER ---- */
    .mk-page { padding: 36px 48px; }

    /* ---- SECTION TITLE ---- */
    .mk-section-title {
        font-size: 22px;
        font-weight: 700;
        color: var(--text-main);
        margin-bottom: 24px;
    }

    /* ---- EMPTY STATE ---- */
    .mk-empty {
        text-align: center;
        padding: 60px 20px;
        color: var(--text-muted);
    }

    .mk-empty .empty-icon { font-size: 56px; margin-bottom: 16px; }
    .mk-empty p { font-size: 16px; }

    /* ---- TABLE ---- */
    .mk-table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: var(--radius-card);
        overflow: hidden;
        box-shadow: var(--shadow);
    }

    .mk-table th {
        background: var(--primary);
        color: white;
        padding: 14px 18px;
        text-align: left;
        font-size: 13px;
        font-weight: 600;
        letter-spacing: 0.4px;
    }

    .mk-table td {
        padding: 14px 18px;
        border-bottom: 1px solid var(--border);
        font-size: 14px;
        color: var(--text-main);
    }

    .mk-table tr:last-child td { border-bottom: none; }
    .mk-table tr:hover td { background: #faf5ff; }

    /* ---- DIVIDER ---- */
    .mk-divider {
        height: 1px;
        background: var(--border);
        margin: 24px 0;
    }

    /* ---- PAGE SPECIFIC STYLES ---- */
    .hero {
        background: linear-gradient(120deg, #1a1a2e 0%, #360060 50%, #4B007D 100%);
        padding: 40px 48px;
        color: white;
        border-radius: 0 0 28px 28px;
        margin-bottom: 36px;
    }
    .hero .hero-row { display: flex; align-items: center; justify-content: space-between; }
    .hero h1 { font-size: 28px; font-weight: 700; margin-bottom: 6px; }
    .hero p { font-size: 15px; opacity: 0.8; }
    .hero .stats { display: flex; gap: 28px; margin-top: 24px; }
    .hero .stat-box {
        background: rgba(255,255,255,0.12);
        border-radius: 14px;
        padding: 14px 24px;
        text-align: center;
        backdrop-filter: blur(10px);
    }
    .hero .stat-box .stat-num { font-size: 22px; font-weight: 700; }
    .hero .stat-box .stat-lbl { font-size: 12px; opacity: 0.75; margin-top: 2px; }

    .cards-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 24px;
        padding: 0 48px 48px;
    }

    .dash-card {
        background: white;
        border-radius: 20px;
        padding: 36px 24px;
        text-align: center;
        box-shadow: 0 4px 20px rgba(75,0,125,0.07);
        border: 1.5px solid #f0ebff;
        cursor: pointer;
        transition: all 0.25s;
        text-decoration: none;
        display: block;
        color: inherit;
    }
    .dash-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 12px 32px rgba(75,0,125,0.18);
        border-color: #b57cff;
    }
    .dash-card .card-icon { font-size: 48px; margin-bottom: 16px; display: block; }
    .dash-card h3 { font-size: 17px; font-weight: 700; color: #1a1a2e; margin-bottom: 8px; }
    .dash-card p { font-size: 13px; color: #6b7280; margin: 0; line-height: 1.5; }
    .dash-card .card-label {
        display: inline-block; margin-top: 16px;
        padding: 7px 18px; background: #4B007D;
        border-radius: 20px; font-size: 12px; font-weight: 600; color: white;
    }
    .dash-card:hover .card-label { background: #ff6f61; }

    @media(max-width: 900px) { .cards-grid { grid-template-columns: 1fr 1fr; } }
    @media(max-width: 600px) { .cards-grid { grid-template-columns: 1fr; padding: 0 20px 32px; } .hero { padding: 32px 20px; } }
</style>
</head>
<body>

<nav class="mk-navbar">
    <div class="logo">Make<span style="color:#ffb3fe">ito</span></div>
    <div class="nav-user">
        <span class="user-badge">&#128736; <%= email %></span>
        <a href="LogoutServlet">Logout</a>
    </div>
</nav>

<div class="hero">
    <div class="hero-row">
        <div>
            <h1>Vendor Dashboard &#128736;</h1>
            <p>Manage your projects, quotes, and orders</p>
        </div>
    </div>
</div>

<div class="cards-grid">

    <a href="ViewProjectsServlet" class="dash-card">
        <span class="card-icon">&#128203;</span>
        <h3>Available Projects</h3>
        <p>Browse open customer projects and submit competitive quotes</p>
        <span class="card-label">Browse Projects</span>
    </a>

    <a href="vendorQuotes.jsp" class="dash-card">
        <span class="card-icon">&#128172;</span>
        <h3>My Quotes</h3>
        <p>Track all quotes you've submitted and their current status</p>
        <span class="card-label">View Quotes</span>
    </a>

    <a href="VendorOrdersServlet" class="dash-card">
        <span class="card-icon">&#128230;</span>
        <h3>My Orders</h3>
        <p>View accepted orders and update their completion status</p>
        <span class="card-label">View Orders</span>
    </a>

</div>

</body>
</html>