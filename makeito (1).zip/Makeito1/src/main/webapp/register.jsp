<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Makeito - Register</title>
    <style>
        body {
            font-family: Arial;
            background: linear-gradient(to right, #2c3e50, #3498db);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .box {
            background: white;
            padding: 40px;
            width: 350px;
            border-radius: 10px;
            box-shadow: 0 0 25px rgba(0,0,0,0.3);
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #27ae60;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background: #219150;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Create Account</h2>

    <form action="RegisterServlet" method="post">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        
        <select name="role">
            <option value="CUSTOMER">Customer</option>
            <option value="VENDOR">Vendor</option>
        </select>

        <button type="submit">Register</button>
    </form>

    <p>Already have account? <a href="login.jsp">Login</a></p>
</div>

</body>
</html>
