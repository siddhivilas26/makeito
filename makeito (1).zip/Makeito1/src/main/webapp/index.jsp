<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    String userEmail = (String) session.getAttribute("userEmail");
        response.sendRedirect("landingPage.jsp");
    
%>

<!DOCTYPE html>
<html>
<head>
    <title>Makeito Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial;
        }

        .navbar {
            background: #2c3e50;
            color: white;
            padding: 15px;
        }

        .navbar span {
            float: right;
        }

        .content {
            padding: 30px;
        }

        .card {
            display: inline-block;
            width: 250px;
            margin: 15px;
            padding: 20px;
            background: #ecf0f1;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
        }

        .card:hover {
            background: #dfe6e9;
        }
    </style>
</head>
<body>

<div class="navbar">
    Welcome to Makeito
    <span>Logged in as: <%= userEmail %></span>
    <a href="LogoutServlet" style="color:white; margin-left:20px;">Logout</a>
    
</div>

<div class="content">
    <div class="card">
        <h3>Wood Fabrication</h3>
        <p>Custom wood projects</p>
    </div>

    <div class="card">
        <h3>Metal Fabrication</h3>
        <p>Industrial metal work</p>
    </div>

    <div class="card">
        <h3>Tool Rental</h3>
        <p>Rent professional tools</p>
    </div>
</div>

</body>
</html>
