<%@ page import="java.sql.*" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<%
    String role = (String) session.getAttribute("userRole");
    String vendorEmail = (String) session.getAttribute("userEmail");

    if(role == null || !role.equals("VENDOR")){
        response.sendRedirect("login.jsp");
        return;
    }

    int projectId = Integer.parseInt(request.getParameter("projectId"));

    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/makeito_db",
        "root",
        "root"
    );

    PreparedStatement ps = con.prepareStatement(
        "SELECT status FROM projects WHERE id=?"
    );
    ps.setInt(1, projectId);

    ResultSet rs = ps.executeQuery();

    if(rs.next()){
        String status = rs.getString("status");

        if(!"OPEN".equals(status)){
            con.close();
            response.sendRedirect("viewProjects.jsp");
            return;
        }
    }

    con.close();
%>

<!DOCTYPE html>
<html>
<head>
<title>Send Quote</title>

<style>
body { font-family: Arial; background:#f4f6f9; padding:40px; }

.box {
    background:white;
    width:400px;
    margin:auto;
    padding:30px;
    border-radius:10px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

input, textarea {
    width:100%;
    padding:10px;
    margin:10px 0;
}

button {
    padding:10px;
    width:100%;
    background:#27ae60;
    color:white;
    border:none;
}
</style>
</head>

<body>

<div class="box">
<h2>Submit Quote</h2>

<form action="QuoteServlet" method="post">
    <input type="hidden" name="projectId" value="<%= projectId %>">

    <input type="number" name="amount" placeholder="Quote Amount" required>

    <textarea name="message" placeholder="Message to Customer"></textarea>

    <button type="submit">Send Quote</button>
</form>

</div>

</body>
</html>
