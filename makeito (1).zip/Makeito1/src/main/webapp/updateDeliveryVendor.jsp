<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%
String orderId=request.getParameter("order_id");
%>

<!DOCTYPE html>
<html>
<head>

<title>Update Delivery</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">

<style>

body{
font-family:'Inter',sans-serif;
background:#f3f4f6;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

.container{
background:white;
padding:40px;
border-radius:12px;
width:400px;
box-shadow:0 8px 25px rgba(0,0,0,0.1);
}

h2{
margin-bottom:20px;
}

select{
width:100%;
padding:12px;
border-radius:8px;
border:1px solid #ccc;
margin-bottom:20px;
}

button{
padding:12px 20px;
border:none;
border-radius:8px;
background:#10b981;
color:white;
cursor:pointer;
font-weight:600;
}

button:hover{
background:#059669;
}

.back{
display:inline-block;
margin-top:15px;
text-decoration:none;
color:#4b5563;
}

.update-btn{
background:#3b82f6;
color:white;
padding:8px 16px;
border-radius:6px;
text-decoration:none;
font-weight:500;
}

.update-btn:hover{
background:#2563eb;
}

</style>

</head>

<body>

<div class="container">

<h2>Update Delivery Status</h2>

<form action="DeliveryUpdateServlet" method="post">

<input type="hidden" name="order_id" value="<%=orderId%>">

<select name="status" required>

<option value="">Select Status</option>
<option value="Packed">Packed</option>
<option value="Shipped">Shipped</option>
<option value="Out for Delivery">Out for Delivery</option>
<option value="Delivered">Delivered</option>

</select>
<input type="submit" >


</form>

<a class="back" href="viewOrdersVendorServlet">← Back to Orders</a>

</div>

</body>
</html>