<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String email = (String) session.getAttribute("userEmail");
    if(email == null){
        response.sendRedirect("login.jsp");
        return;
    }
    String amountStr = request.getParameter("advanceAmount");
    String displayAmount = (amountStr != null) ? amountStr : "0.00";
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Checkout</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f2f4f8;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .checkout-container {
            width: 100%;
            max-width: 800px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        /* Header / Order Summary */
        .checkout-header {
            background: #1a1a1a;
            color: #ffffff;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .checkout-header h2 { margin: 0; font-size: 20px; font-weight: 500; }
        .checkout-header .amount { font-size: 24px; font-weight: bold; color: #2ecc71; }

        /* Split Pane Layout */
        .payment-body {
            display: flex;
            min-height: 400px;
        }

        /* Left Sidebar - Payment Methods */
        .payment-sidebar {
            width: 35%;
            background: #f9fbfc;
            border-right: 1px solid #e1e8ed;
        }

        .payment-method-tab {
            padding: 20px;
            cursor: pointer;
            border-bottom: 1px solid #e1e8ed;
            color: #555;
            font-weight: 500;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
        }

        .payment-method-tab:hover { background: #f0f4f8; }
        
        .payment-method-tab.active {
            background: #ffffff;
            border-left: 4px solid #3498db;
            color: #3498db;
            font-weight: bold;
        }

        /* Right Main Content - Forms */
        .payment-content {
            width: 65%;
            padding: 30px;
            position: relative;
        }

        .tab-content { display: none; }
        .tab-content.active { display: block; animation: fadeIn 0.3s; }

        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }

        /* Form Styling */
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; color: #333; font-size: 14px; font-weight: 500; }
        
        input[type="text"], input[type="password"], select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        input:focus, select:focus { border-color: #3498db; outline: none; }

        .flex-row { display: flex; gap: 15px; }
        .flex-row > div { flex: 1; }

        /* Trust Badge & Button */
        .secure-badge {
            text-align: center;
            color: #7f8c8d;
            font-size: 12px;
            margin-bottom: 15px;
        }

        .pay-btn {
            width: 100%;
            padding: 15px;
            background: #2ecc71;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 10px;
        }

        .pay-btn:hover { background: #27ae60; }
        
        /* Specific element styles */
        .upi-apps { display: flex; gap: 10px; margin-bottom: 15px; }
        .upi-app { padding: 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px; color: #555; background: #fff; flex: 1; text-align: center; }
    </style>
</head>
<body>

<div class="checkout-container">
    <div class="checkout-header">
        <h2>Makeito Secure Checkout</h2>
        <div class="amount">₹<%= displayAmount %></div>
    </div>
    <%
    String am = request.getParameter("quoteId");
%>

    <form action="AcceptQuoteServlet" method="get" id="paymentForm">

    <input type="hidden" name="quoteId" value="<%= request.getParameter("quoteId") %>">
    <input type="hidden" name="projectId" value="<%= request.getParameter("projectId") %>">
    <input type="hidden" name="advanceAmount" value="<%= displayAmount %>">
     <input type="hidden" name="amount" value="<%= request.getParameter("amount") %>">
    <input type="hidden" name="paymentMethod" id="selectedPaymentMethod" value="UPI">
        <div class="payment-body">
            
            <div class="payment-sidebar">
                <div class="payment-method-tab active" onclick="switchTab('upi', 'UPI', this)">
                    UPI Apps
                </div>
                <div class="payment-method-tab" onclick="switchTab('card', 'CARD', this)">
                    Credit / Debit Card
                </div>
                <div class="payment-method-tab" onclick="switchTab('netbanking', 'NET_BANKING', this)">
                    Net Banking
                </div>
                <div class="payment-method-tab" onclick="switchTab('cod', 'COD', this)">
                    Cash on Delivery
                </div>
            </div>

            <div class="payment-content">
                
                <div id="upi" class="tab-content active">
                    <h3>Pay via UPI</h3>
                    <div class="upi-apps">
                        <div class="upi-app">GPay</div>
                        <div class="upi-app">PhonePe</div>
                        <div class="upi-app">Paytm</div>
                    </div>
                    <div class="form-group">
                        <label>Virtual Payment Address (UPI ID)</label>
                        <input type="text" name="upiId" placeholder="e.g., yourname@bank">
                    </div>
                </div>

                <div id="card" class="tab-content">
                    <h3>Enter Card Details</h3>
                    <div class="form-group">
                        <label>Card Number</label>
                        <input type="text" name="cardNumber" placeholder="0000 0000 0000 0000" maxlength="19">
                    </div>
                    <div class="flex-row">
                        <div class="form-group">
                            <label>Expiry Date</label>
                            <input type="text" name="expiry" placeholder="MM / YY" maxlength="5">
                        </div>
                        <div class="form-group">
                            <label>CVV</label>
                            <input type="password" name="cvv" placeholder="123" maxlength="4">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Name on Card</label>
                        <input type="text" name="cardName" placeholder="John Doe">
                    </div>
                </div>

                <div id="netbanking" class="tab-content">
                    <h3>Select your Bank</h3>
                    <div class="form-group">
                        <label>Popular Banks</label>
                        <select name="bankName">
                            <option value="">-- Choose your Bank --</option>
                            <option value="HDFC">HDFC Bank</option>
                            <option value="SBI">State Bank of India</option>
                            <option value="ICICI">ICICI Bank</option>
                            <option value="AXIS">Axis Bank</option>
                            <option value="KOTAK">Kotak Mahindra Bank</option>
                        </select>
                    </div>
                </div>

                <div id="cod" class="tab-content">
                    <h3>Cash on Delivery</h3>
                    <p style="color: #666; font-size: 14px; line-height: 1.5;">
                        You have selected Cash on Delivery. Please keep the exact change ready at the time of delivery. 
                        A handling fee may apply.
                    </p>
                </div>

                <div style="margin-top: 30px;">
                    <div class="secure-badge">
                        🔒 100% Secure & Encrypted Payments
                    </div>
                    <button type="submit" class="pay-btn">Pay ₹<%= displayAmount %></button>
                </div>

            </div>
        </div>
    </form>
</div>

<script>
    function switchTab(tabId, paymentMethodValue, element) {
        // 1. Hide all tab contents
        var contents = document.getElementsByClassName('tab-content');
        for (var i = 0; i < contents.length; i++) {
            contents[i].classList.remove('active');
        }

        // 2. Remove 'active' class from all tabs in the sidebar
        var tabs = document.getElementsByClassName('payment-method-tab');
        for (var i = 0; i < tabs.length; i++) {
            tabs[i].classList.remove('active');
        }

        // 3. Show the selected tab content
        document.getElementById(tabId).classList.add('active');

        // 4. Highlight the clicked tab
        element.classList.add('active');

        // 5. Update the hidden input field so the Servlet knows what was chosen
        document.getElementById('selectedPaymentMethod').value = paymentMethodValue;
        
        // 6. Change button text dynamically for COD
        var btn = document.querySelector('.pay-btn');
        if(paymentMethodValue === 'COD') {
            btn.innerHTML = 'Place Order';
        } else {
            btn.innerHTML = 'Pay ₹<%= displayAmount %>';
        }
    }
</script>

</body>
</html>