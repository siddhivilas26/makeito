<%@ page import="java.sql.*" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String role = (String) session.getAttribute("userRole");
    String customerEmail = (String) session.getAttribute("userEmail");

    if(role == null || !role.equals("CUSTOMER")){
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
<title>My Project Quotes</title>

<style>
body { font-family: Arial; background:#f4f6f9; padding:40px; }

.card {
    background:white;
    padding:20px;
    margin:20px 0;
    border-radius:8px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

.btn {
    padding:8px 12px;
    background:#3498db;
    color:white;
    text-decoration:none;
    border-radius:5px;
}
</style>
</head>

<body>

<h1>Quotes For My Projects</h1>

<%
try {

    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/makeito_db",
        "root",
        "root"
    );

    PreparedStatement ps = con.prepareStatement(
        "SELECT q.*, p.title FROM quotes q " +
        "JOIN projects p ON q.project_id = p.id " +
        "WHERE p.customer_email = ?"
    );

    ps.setString(1, customerEmail);

    ResultSet rs = ps.executeQuery();

    while(rs.next()){
%>

    <div class="card">
        <h3>Project: <%= rs.getString("title") %></h3>
        <p><b>Vendor:</b> <%= rs.getString("vendor_email") %></p>
        <p><b>Amount:</b> ₹<%= rs.getDouble("amount") %></p>
<%
    double amount = rs.getDouble("amount");
    double advanceAmount = (amount * 10) / 100;   // exact 10%
%>

<p><b>Advance Amount:</b> ₹<%= advanceAmount %></p><p><%= rs.getString("message") %></p>

        <% if("PENDING".equals(rs.getString("status"))) { %>
    <a class="btn"
       href="payments.jsp?quoteId=<%= rs.getInt("id") %>&projectId=<%= rs.getInt("project_id") %>&advanceAmount=<%=advanceAmount%>&amount=<%=amount%>">
       Pay Advance To Accept Quote
    </a>
<% } else { %>
    <p><b>Status:</b> <%= rs.getString("status") %></p>
<% } %>

    </div>

<%
    }

    con.close();

} catch(Exception e){
    e.printStackTrace();
}
%>

</body>
</html>
