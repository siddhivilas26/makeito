<%@ page contentType="text/html;charset=UTF-8" %>
<%
    // Keeping your logic intact
    String email = (String) session.getAttribute("userEmail");
    if(email == null){
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Project | Makeito</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #7b2ff7, #f107a3);
            --glass-bg: rgba(255, 255, 255, 0.95);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f3f4ff, #eef1ff);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: var(--glass-bg);
            width: 100%;
            max-width: 550px;
            padding: 40px;
            border-radius: 24px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        .container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: var(--primary-gradient);
            border-radius: 24px 24px 0 0;
        }

        h2 {
            font-size: 28px;
            font-weight: 700;
            color: #2c2c2c;
            margin-bottom: 8px;
            text-align: center;
        }

        p.subtitle {
            text-align: center;
            color: #777;
            font-size: 14px;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #4b007d;
            margin-bottom: 8px;
            margin-left: 4px;
        }

        input[type="text"],
        input[type="number"],
        textarea {
            width: 100%;
            padding: 14px 18px;
            border: 2px solid #eef0f7;
            border-radius: 12px;
            font-size: 14px;
            transition: all 0.3s ease;
            outline: none;
            background: #fdfdff;
        }

        input:focus, textarea:focus {
            border-color: #7b2ff7;
            background: #fff;
            box-shadow: 0 5px 15px rgba(123, 47, 247, 0.1);
        }

        textarea {
            height: 120px;
            resize: none;
        }

        /* Custom File Upload Styling */
        .file-upload-wrapper {
            position: relative;
            border: 2px dashed #d1d5db;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            transition: 0.3s;
            background: #fafbff;
            cursor: pointer;
        }

        .file-upload-wrapper:hover {
            border-color: #7b2ff7;
            background: #f3f0ff;
        }

        .file-upload-wrapper input[type="file"] {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
            cursor: pointer;
        }

        .upload-icon {
            font-size: 24px;
            margin-bottom: 8px;
            display: block;
        }

        .upload-text {
            font-size: 13px;
            color: #666;
        }

        button {
            width: 100%;
            padding: 16px;
            margin-top: 10px;
            border: none;
            border-radius: 12px;
            background: var(--primary-gradient);
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
            box-shadow: 0 10px 20px rgba(123, 47, 247, 0.2);
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 25px rgba(123, 47, 247, 0.3);
            filter: brightness(1.1);
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 13px;
            color: #888;
            text-decoration: none;
        }

        .back-link:hover {
            color: #7b2ff7;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Submit New Project</h2>
    <p class="subtitle">Fill in the details to share your vision with our makers.</p>

    <form action="ImageProjectUploadServlet" method="post" enctype="multipart/form-data">
        
        <div class="form-group">
            <label>PROJECT TITLE</label>
            <input type="text" name="title" placeholder="e.g. Modern Steel Coffee Table" required>
        </div>

        <div class="form-group">
            <label>DESCRIPTION</label>
            <textarea name="description" placeholder="Describe the materials, dimensions, and any specific requirements..." required></textarea>
        </div>

        <div class="form-group">
            <label>ESTIMATED BUDGET ($)</label>
            <input type="number" name="budget" placeholder="0.00" required>
        </div>

        <div class="form-group">
            <label>DESIGN REFERENCE (OPTIONAL)</label>
            <div class="file-upload-wrapper">
                <span class="upload-icon">📤</span>
                <span class="upload-text">Click to upload or drag and drop</span>
                <input type="file" name="image" id="fileInput">
            </div>
            <p id="fileName" style="font-size: 12px; color: #7b2ff7; margin-top: 5px; text-align: center; font-weight: 500;"></p>
        </div>

        <button type="submit">Launch Project</button>
    </form>

    <a href="customerDashboard.jsp" class="back-link">← Back to Dashboard</a>
</div>

<script>
    // Simple UX script to show selected filename
    const fileInput = document.getElementById('fileInput');
    const fileNameDisplay = document.getElementById('fileName');

    fileInput.addEventListener('change', function() {
        if (this.files && this.files.length > 0) {
            fileNameDisplay.textContent = "Selected: " + this.files[0].name;
        }
    });
</script>

</body>
</html>