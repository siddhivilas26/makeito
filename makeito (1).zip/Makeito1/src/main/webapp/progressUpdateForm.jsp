<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String orderId = request.getParameter("id");   // from vendorOrders.jsp
%>

<!DOCTYPE html>
<html>
<head>
<title>Update Order & Delivery</title>

<style>
    body {
        font-family: 'Inter', sans-serif;
        background: #eef2f7;
        padding: 40px;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        gap: 25px;
    }

    .form-box {
        background: white;
        padding: 25px;
        width: 420px;
        border-radius: 14px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    }

    h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 6px;
        font-weight: 600;
    }

    select, input {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 8px;
        margin-bottom: 15px;
    }

    .btn {
        width: 100%;
        padding: 12px;
        background: #0066ff;
        border: none;
        color: white;
        font-weight: 600;
        border-radius: 8px;
        cursor: pointer;
    }

    .btn:hover {
        background: #004ecc;
    }
</style>

</head>
<body>

<!-- ORDER PROGRESS UPDATE -->
<div class="form-box">
    <h2>Order Progress</h2>

    <form action="ProgressUpdateFormServlet" method="get">

        <input type="hidden" name="id" value="<%= orderId %>">

        <label>Status</label>
        <select name="status" required>
            <option value="PENDING">PENDING</option>
            <option value="IN_PROGRESS">IN_PROGRESS</option>
            <option value="COMPLETED">COMPLETED</option>
        </select>

        <label>Completion %</label>
        <input type="number" name="complete_percentage" min="0" max="100" required>

        <button class="btn">Update Order Progress</button>
    </form>
</div>


</body>
</html>