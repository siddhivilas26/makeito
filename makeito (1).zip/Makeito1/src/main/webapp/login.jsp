<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Makeito - Login</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: #F8F9FF;
            min-height: 100vh;
        }

        /* ================= NAVBAR ================= */
        .navbar {
            width: 100%;
            background: #4B0066;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 18px 60px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .logo {
            font-size: 22px;
            font-weight: 700;
        }

        .menu a {
            color: white;
            margin-left: 35px;
            text-decoration: none;
            font-size: 15px;
            transition: 0.3s;
        }

        .menu a:hover {
            color: #FF5757;
        }

        /* ================= PAGE LAYOUT ================= */
        .main-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 80px 20px;
            position: relative;
        }

        /* Background soft glow */
        .main-wrapper::before {
            content: "";
            position: absolute;
            width: 400px;
            height: 400px;
            background: #FF5757;
            opacity: 0.08;
            border-radius: 50%;
            filter: blur(120px);
            top: 10%;
            left: 20%;
        }

        .login-card {
            background: white;
            width: 100%;
            max-width: 500px;
            padding: 50px 40px;
            border-radius: 25px;
            box-shadow: 0 30px 60px rgba(0,0,0,0.08);
            text-align: center;
            position: relative;
            z-index: 1;
        }

        .icon-circle {
            width: 90px;
            height: 90px;
            background: rgba(75,0,102,0.08);
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto 25px auto;
            font-size: 42px;
            color: #4B0066;
        }

        h2 {
            font-size: 26px;
            font-weight: 700;
            margin-bottom: 8px;
            color: #4B0066;
        }

        .subtitle {
            font-size: 14px;
            color: #666;
            margin-bottom: 30px;
        }

        /* ================= INPUT FIELDS ================= */
        .input-group {
            text-align: left;
            margin-bottom: 20px;
        }

        .input-group label {
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 6px;
            display: block;
            color: #444;
        }

        input {
            width: 100%;
            padding: 14px;
            border-radius: 12px;
            border: 1px solid #ddd;
            font-size: 14px;
            transition: 0.3s;
            background: #fafafa;
        }

        input:focus {
            border-color: #4B0066;
            box-shadow: 0 0 0 3px rgba(75,0,102,0.1);
            background: white;
            outline: none;
        }

        /* ================= BUTTON ================= */
        .submit-btn {
            width: 100%;
            background: #FF5757;
            color: white;
            padding: 15px;
            border: none;
            border-radius: 14px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 10px;
            transition: all 0.3s ease;
            box-shadow: 0 12px 25px rgba(255,87,87,0.3);
        }

        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 18px 35px rgba(255,87,87,0.5);
        }

        /* ================= ERROR ================= */
        .error {
            background: rgba(255,87,87,0.1);
            color: #FF5757;
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        /* ================= PRIVACY ================= */
        .privacy {
            margin-top: 25px;
            font-size: 13px;
            color: #4B0066;
            opacity: 0.7;
        }

        @media(max-width:768px) {
            .navbar {
                padding: 18px 25px;
            }
            .menu {
                display: none;
            }
        }
    </style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="logo">Makeito</div>
    <div class="menu">
        <a href="#">Features</a>
        <a href="#">Services</a>
        <a href="#">Testimonials</a>
        <a href="#">Contact</a>
    </div>
</div>

<!-- LOGIN SECTION -->
<div class="main-wrapper">

    <div class="login-card">

        <div class="icon-circle">👤</div>

        <h2>Welcome Back</h2>
        <div class="subtitle">Login to access your dashboard</div>

        <% if(request.getAttribute("error") != null) { %>
            <div class="error"><%= request.getAttribute("error") %></div>
        <% } %>

        <form action="LoginServlet" method="post">

            <div class="input-group">
                <label>Email Address</label>
                <input type="email" name="email" placeholder="example@mail.com" required>
            </div>

            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter your password" required>
            </div>

            <button type="submit" class="submit-btn">
                Continue to Services
            </button>

        </form>

        <div class="privacy">Your privacy is 100% secure.</div>

    </div>

</div>

</body>
</html>