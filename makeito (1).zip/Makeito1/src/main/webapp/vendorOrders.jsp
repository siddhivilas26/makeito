<%@ page import="java.util.List" %>
<%@ page import="com.makeito.servlet.Order" %>

<%
List<Order> orders = (List<Order>) request.getAttribute("orders");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Vendor Dashboard</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Inter',sans-serif;
}

body{
display:flex;
background:#f8fafc;
}

/* SIDEBAR */

.sidebar{
width:240px;
background:#111827;
min-height:100vh;
color:white;
padding:30px 20px;
}

.sidebar h2{
font-size:22px;
margin-bottom:40px;
}

.sidebar a{
display:block;
color:#9ca3af;
text-decoration:none;
padding:12px;
border-radius:8px;
margin-bottom:10px;
transition:0.2s;
}

.sidebar a:hover{
background:#1f2937;
color:white;
}

/* MAIN AREA */

.main{
flex:1;
padding:30px 40px;
}

/* HEADER */

.header{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:30px;
}

.header h1{
font-size:26px;
}

.profile{
background:#e5e7eb;
width:36px;
height:36px;
border-radius:50%;
}

/* STATS */

.stats{
display:grid;
grid-template-columns:repeat(4,1fr);
gap:20px;
margin-bottom:30px;
}

.stat-card{
background:white;
padding:20px;
border-radius:12px;
box-shadow:0 4px 10px rgba(0,0,0,0.05);
}

.stat-card h3{
font-size:14px;
color:#6b7280;
}

.stat-card p{
font-size:22px;
font-weight:600;
margin-top:6px;
}

/* ORDERS */

.orders-container{
max-width:900px;
}

.order-card{
background:white;
border-radius:12px;
margin-bottom:15px;
border:1px solid #e5e7eb;
overflow:hidden;
transition:0.2s;
}

.order-card:hover{
box-shadow:0 6px 20px rgba(0,0,0,0.08);
}

.order-summary{
padding:20px;
display:flex;
justify-content:space-between;
align-items:center;
cursor:pointer;
}

.order-left{
display:flex;
flex-direction:column;
}

.order-title{
font-weight:600;
}

.order-email{
font-size:13px;
color:#6b7280;
}

.order-right{
display:flex;
gap:20px;
align-items:center;
}

.status{
padding:4px 12px;
border-radius:20px;
font-size:12px;
font-weight:600;
background:#dbeafe;
color:#1e40af;
}

.amount{
font-weight:600;
}

.chevron{
width:18px;
transition:0.3s;
}

.order-card.active .chevron{
transform:rotate(180deg);
}

/* EXPAND */

.expand{
display:none;
padding:20px;
border-top:1px solid #e5e7eb;
background:#fafafa;
}

.expand-content{
display:flex;
justify-content:space-between;
align-items:center;
}

/* BUTTONS */

.buttons{
display:flex;
gap:10px;
}

.btn{
padding:10px 18px;
border-radius:8px;
font-size:14px;
text-decoration:none;
font-weight:500;
}

.btn-edit{
background:#4f46e5;
color:white;
}

.btn-view{
background:#e5e7eb;
color:black;
}

.btn-edit:hover{
background:#4338ca;
}

.btn-view:hover{
background:#d1d5db;
}

.btn-delivery{
background:#10b981;
color:white;
}

.btn-delivery:hover{
background:#059669;
}

</style>

<script>

function toggleCard(index){

let card=document.getElementById("card-"+index);
let box=document.getElementById("box-"+index);

let allCards=document.getElementsByClassName("order-card");
let allBoxes=document.getElementsByClassName("expand");

for(let i=0;i<allBoxes.length;i++){

if(allBoxes[i]!=box){
allBoxes[i].style.display="none";
allCards[i].classList.remove("active");
}

}

if(box.style.display==="block"){
box.style.display="none";
card.classList.remove("active");
}
else{
box.style.display="block";
card.classList.add("active");
}

}

</script>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

<h2>MakeIt</h2>

<a href="vendor.jsp">Dashboard</a>
<a href="#">Orders</a>
<a href="#">Products</a>
<a href="#">Customers</a>
<a href="#">Analytics</a>
<a href="#">Settings</a>

</div>

<!-- MAIN -->

<div class="main">

<div class="header">

<h1>Orders Assigned To Me</h1>

<div class="profile"></div>

</div>

<!-- STATS -->

<div class="stats">

<div class="stat-card">
<h3>Total Orders</h3>
<p><%= orders!=null?orders.size():0 %></p>
</div>

<div class="stat-card">
<h3>Pending</h3>
<p>12</p>
</div>

<div class="stat-card">
<h3>In Progress</h3>
<p>8</p>
</div>

<div class="stat-card">
<h3>Completed</h3>
<p>21</p>
</div>

</div>

<!-- ORDERS -->

<div class="orders-container">

<%
if(orders!=null){

int index=0;

for(Order o:orders){
%>

<div class="order-card" id="card-<%=index%>">

<div class="order-summary" onclick="toggleCard(<%=index%>)">

<div class="order-left">
<div class="order-title"><%=o.getTitle()%></div>
<div class="order-email"><%=o.getCustomerEmail()%></div>
</div>

<div class="order-right">

<span class="status"><%=o.getStatus()%></span>

<div class="amount">$<%=o.getAmount()%></div>

<svg class="chevron" viewBox="0 0 24 24">
<polyline points="6 9 12 15 18 9" stroke="black" fill="none" stroke-width="2"/>
</svg>

</div>

</div>

<div class="expand" id="box-<%=index%>">

<div class="expand-content">

<div>
<p style="color:#6b7280;font-size:13px;">Order Details</p>
<p style="font-weight:600;">Order ID : #<%=o.getId()%></p>
</div>

<div class="buttons">

<a href="progressUpdateForm.jsp?id=<%=o.getId()%>" class="btn btn-edit">
Edit Order
</a>

<a href="viewOrdersVendorServlet?id=<%=o.getId()%>" class="btn btn-view">
View Order
</a>

<a href="updateDeliveryVendor.jsp?order_id=<%=o.getId()%>" class="btn btn-delivery">
Update Delivery
</a>

</div>

</div>

</div>

</div>

<%
index++;
}
}
else{
%>

<p>No orders assigned.</p>

<%
}
%>

</div>

</div>

</body>
</html>

